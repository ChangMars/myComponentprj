﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SqlFrameworkLibrary
{
    public class General
    {
        //2021/10/26 新增
        //2022/03-24 新增 車廠

        //2022/3/15 For Test
        private static string connAp01_Test = Utility.Basic.connAp01_Test;
        //正式
        private static string connAp01_54 = Utility.Basic.connAp01_54;
        private static string connAp02 = Utility.Basic.connAp02;
        private static string connAp03 = Utility.Basic.connAp03;


        //connModBus
        private static string connModBus = Utility.Basic.connModBus;


        //SQL執行狀況
        public static bool YLConnectState = true;
        //交易錯誤訊息
        public static string YLConnectError;
        //SQL連線
        private static SqlConnection connection;
        //SQL命令
        private static SqlCommand command;
        //交易定義
        private static SqlTransaction transaction;

        #region "link"
        //取得連線
        static public string Getcon(string con)
        {
            string Lkstring = "";
            switch (con)
            {
                case "connAp01_Test":
                    Lkstring = connAp01_Test;
                    break;
                case "connAp01":
                    Lkstring = connAp01_54;
                    break;
                case "connAp02":
                    Lkstring = connAp02;
                    break;
                case "connAp03":
                    Lkstring = connAp03;
                    break;
                case "connModBus":
                    Lkstring = connModBus;
                    break;

            }

            return Lkstring;
        }




        static public List<dynamic> QueryAp01(string results)
        {
            return Query(connAp01_54, results);
        }
        static public List<T> QueryAp01<T>(string results)
        {
            return Query<T>(connAp01_54, results);
        }

        static public List<dynamic> QueryAp02(string results)
        {
            return Query(connAp02, results);
        }
        static public List<T> QueryAp02<T>(string results)
        {
            return Query<T>(connAp02, results);
        }
        static public List<dynamic> QueryAp03(string results)
        {
            return Query(connAp03, results);
        }
        static public List<T> QueryAp03<T>(string results)
        {
            return Query<T>(connAp03, results);
        }
        static public DataTable DataTableQuery(string conn, string cmd)
        {
            DataTable results = new DataTable();

            using (SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd, conn))
            {
                dataAdapter.Fill(results);
            }
            return results;
        }
        //============================================
        static public void YLLKStart(string conn)
        {
            connection = new SqlConnection(conn);
        }
        static public void YLLKClose()
        {
            connection.Close();
        }
        static public void BeginTransaction()
        {
            connection.Open();
            command = connection.CreateCommand();
            // Start a local transaction.
            transaction = connection.BeginTransaction("SampleTransaction");
            // Must assign both transaction object and connection
            // to Command object for a pending local transaction
            command.Connection = connection;
            command.Transaction = transaction;
        }
        static public void Commit()
        {
            transaction.Commit();
        }
        static public void RollBack()
        {
            transaction.Rollback();
        }
        static public  void YLQuery(string cmd)
        {
                //初始錯誤訊息
                YLConnectError="";

                try
                {
                    Console.WriteLine(cmd);
                    //command.CommandText =
                    //    "Insert into Region (RegionID, RegionDescription) VALUES (100, 'Description')";
                    //command.ExecuteNonQuery();
                    command.CommandText = cmd;
                    command.ExecuteNonQuery();
                    // Attempt to commit the transaction.
                    //transaction.Commit();
               
                }
                catch (Exception ex)
                {
                     YLConnectState = false;
                    // Attempt to roll back the transaction.
                    
                    
                try
                {
                    //transaction.Rollback();
                    Console.WriteLine("Commit Exception Type: {0}", ex.GetType());
                    Console.WriteLine("  Message: {0}", ex.Message);
                    YLConnectError = ex.Message;
                }
                catch (Exception ex2)
                {
                    // This catch block will handle any errors that may have occurred
                    // on the server that would cause the rollback to fail, such as
                    // a closed connection.
                        
                    Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType());
                    Console.WriteLine("  Message: {0}", ex2.Message);
                    YLConnectError = ex2.Message;


                }
          
            }


            // connection.Query(cmd);
       


        }
        static public List<dynamic> Query(string conn, string cmd)
        {
            List<dynamic> results = new List<dynamic>();

            using (SqlConnection connection = new SqlConnection(conn))
            {
                results = connection.Query(cmd).ToList();
  


            }
            return results;
        }

        static public List<T> Query<T>(string conn, string cmd)
        {
            List<T> results = new List<T>();

            using (SqlConnection connection = new SqlConnection(conn))
            {
                results = connection.Query<T>(cmd).ToList();
            }
            return results;
        }

        static public void Excute(string conn, string cmd, List<dynamic> results)
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Execute(cmd, results); // could using Insert Update
            }
        }

        
        static public void Excute(string conn, string cmd, dynamic results)
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Execute(cmd, new { results }); // could using Insert Update
            }
        }

        static public void Excute<T>(string conn, string cmd, List<T> results)
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Execute(cmd, results); // could using Insert Update Delete
            }
        }

        static public void Excute<T>(string conn, string cmd, T results)
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Execute(cmd, results); // could using Insert Update Delete
            }
        }

        static public string BasicCmd(string from, string select = "*", string where = "", string order = "", string final = "")
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"SELECT {select} ");
            sb.Append($"FROM {from} ");
            if (!string.IsNullOrEmpty(where))
                sb.Append($"WHERE {where} ");
            if (!string.IsNullOrEmpty(order))
                sb.Append($"ORDER BY {order} ");
            if (!string.IsNullOrEmpty(final))
                sb.Append($"{final} ");

            string cmd = sb.ToString();

            return cmd;
        }


        static public string BulkInsertCmd() // temp only using in dapper
        {
            return "INSERT INTO [dbo].[YULON_AS_車型編號]" +
                "([年份] ,[分類] ,[車型] ,[DST] ,[約當比] ,[建立日期] ,[作廢] ,[作廢日期])" +
                "VALUES" +
                "(@年份 ,@分類 ,@車型 ,@DST ,@約當比 ,@建立日期 ,@作廢 ,@作廢日期);";
        }
        #endregion
    }


    public class DoSqlClass
    {
        //2022 03 25
        //森洋
        //使用範例
        //DoSqlClass CNN = new DoSqlClass();
        //CNN.GetValue("SheetName", rows, DataTable.Columns);
        //string sql = CNN.MakeInsSql();

        //資料表
        private string Sheet;
        //行為
        private string Action;
        //錯誤訊息
        public string WrongMsg;
        //Sql
        //插入 則要給Row
        //欄位 ex: dt.column
        private DataRow Row;
        private DataColumnCollection Col;

        public void GetValue(string Sheet, DataRow Row, DataColumnCollection Col)
        {
            //insert 用
            this.Row = Row;
            this.Sheet = Sheet;
            this.Action = "insert";
            this.Col = Col;
            //刷新
            this.WrongMsg = "";
        }


        private Boolean ChkValues()
        {
            Boolean Result = true;
            if (Sheet == "")
            {
                WrongMsg += "Sheet未填[資料表名稱]";
                return false;
            };
            if (Col.Count == 0)
            {
                WrongMsg += "Col未填[資料表欄位名稱]";
                return false;
            };

            return Result;
        }
        //給予DataRow 直接串出 insert in to 的字串
        //此function只串欄位
        public string MakeInsSql()
        {

            string col = "";
            string Sql = "";


            //檢查參數
            if (!ChkValues()) return "";

            //起始數量  For填欄位
            int col_cnt = 1;
            //串欄位字串
            foreach (var EachCol in Col)
            {
                //形成
                //a,b,c   .... values....
                col += col_cnt == 1 ? "" : "";
                col += col_cnt < Col.Count ? " " + EachCol + "," : " " + EachCol;
                col_cnt++;
            }
            //選擇行為
            switch (Action)
            {
                case "query":
                    break;
                case "insert":
                    Sql = String.Format("INSERT INTO {0} ({1}) VALUES ", Sheet, col);
                    break;
                case "update":
                    break;
                case "delete":
                    break;
            }

            //填值
            //做以下事情
            //values ......  'a','b','c'
            string _Sql = FillValues(Sql);

            return _Sql;
        }
        private string FillValues(string Sql)
        {
            string values = "";
            //foreach (DataRow rows in Col)
            //{
            DataRow rows = Row;
            //起始數量2 For填值
            int col_cnt2 = 1;
            //繞columns Name
            foreach (var EachCol in Col)
            {
                //目前碰到 時間有問題
                //如果欄位有其他型態
                //需要在此轉型

                //取得欄位 轉string
                string RowValue = rows[EachCol.ToString()].ToString();
                //如果是時間欄位 轉型Datatime 再轉string 
                string GetValue = (RowValue.Contains("上午") || RowValue.Contains("下午")) ?
                Convert.ToDateTime(rows[EachCol.ToString()].ToString()).ToString("yyyy/MM/dd HH:mm:ss")
                :
                RowValue;

                //如果是最後一個欄位 不再加逗號
                //'a', 'b', 'c'
                values += col_cnt2 < Col.Count ? " '" + GetValue + "'," : " '" + GetValue + "'";
                col_cnt2++;
            }
            //}

            Sql += "( " + values + ")";




            return Sql;
        }
    }
}
