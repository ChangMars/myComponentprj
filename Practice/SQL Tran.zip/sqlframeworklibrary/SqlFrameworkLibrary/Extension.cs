﻿using Dapper.Contrib;
//using DapperExtensions; // Map 需要自定義
using Dapper.Contrib.Extensions; // Map 可由 Class 定義
//using Z.Dapper.Plus; // 可用bulk
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace SqlFrameworkLibrary
{
    public class Extension
    {
        private static string connAp01_54 = Utility.Basic.connAp01_54;
        private static string connAp01 = Utility.Basic.connAp01;
        private static string connAp02 = Utility.Basic.connAp02;
        private static string connAp03 = Utility.Basic.connAp03;
        //static public void BulkInsertDataTableAp01(DataTable results)
        //{
        //    Extension.BulkInsertDataTable(connAp01_54, results);
        //}

        static public void BulkInsertAp01<T>(List<T> results) where T : class
        {
            Extension.BulkInsert(connAp01_54, results);
        }

        //static public void BulkInsertAp01_54<T>(List<T> results) where T : class
        //{
        //    Extension.BulkInsert(connAp01_54, results);
        //}

        static public void BulkInsertAp02<T>(List<T> results) where T : class
        {
            Extension.BulkInsert(connAp02, results);
        }

        //static public void BulkInsertAp01<T>(T results) where T : class
        //{
        //    Extension.BulkInsert(connAp01_54, results);
        //}

        static public void InsertAp01<T>(T results) where T : class
        {
            Extension.Insert(connAp01_54, results);
        }

        static public void InsertAp02<T>(T results) where T : class
        {
            Extension.Insert(connAp02, results);
        }

        public static void UpdateAp01<T>(T results) where T : class
        {
            Extension.Update(connAp01_54, results);
        }
        public static void UpdateAp02<T>(T results) where T : class
        {
            Extension.Update(connAp02, results);
        }
        static public void BulkInsertAp03<T>(List<T> results) where T : class
        {
            Extension.BulkInsert(connAp03, results);
        }

        // =========================================================================
        static public T Get<T>(string conn) where T : class
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                var results = (connection).Get<T>(1);
                return results;
            }
        }

        /// <summary>
        /// Bulk Insert Z.Dapper.Plus 方法，速度比原Dapper.Insert快，10k資料量，約8.5sec Insert完成
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="conn"></param>
        /// <param name="results"></param>
        //static public void BulkInsert<T>(string conn, T results) where T : class
        //{
        //    var tOf = results.GetType();
        //    string tName = tOf.Name;

        //    using (SqlConnection connection = new SqlConnection(conn))
        //    {
        //        connection.Open();
        //        //connection.Execute($"SET IDENTITY_INSERT [{tName}]  ON  ");
        //        connection.BulkInsert(results);
        //        //connection.Execute($"SET IDENTITY_INSERT [{tName}]  OFF  ");
        //        connection.Close();
        //    }
        //}

        /// <summary>
        /// Bulk Insert ADO.NET 方法，可靠速度快，10k資料量，約7.5sec Insert完成，轉換List改DataTable
        /// </summary>
        /// <param name="conn"></param>
        /// <param name="results"></param>
        static public void BulkInsert<T>(string conn, List<T> results) where T : class
        {
            var tOf = results.GetType();
            string tName = tOf.Name;

            string name = results.First().GetType().Name;
            if (results.Any())
            {
                var cusName = Method.Convert.TableNameMapper(results.First().GetType());
                // Dapper 取得設定的 table name
                name = (string.IsNullOrEmpty(cusName)) ? name : cusName;
            }

            var v = Method.Convert.Convert2Type(results);
            var dt = Method.Convert.Convert2DataTable(v, name);

            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Open();
                //connection.Execute($"SET IDENTITY_INSERT [{tName}]  ON  ");
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                {
                    bulkCopy.DestinationTableName = dt.TableName;

                    try
                    {
                        // Write from the source to the destination.
                        bulkCopy.WriteToServer(dt);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        throw new Exception(ex.Message);
                    }
                    finally
                    {
                        // Close the SqlDataReader. The SqlBulkCopy
                        // object is automatically closed at the end
                        // of the using block.
                        //results.Close();
                    }
                }
                //connection.Execute($"SET IDENTITY_INSERT [{tName}]  OFF  ");
                connection.Close();
            }
        }

        static public void Insert<T>(string conn, T results) where T : class
        {
            var tOf = results.GetType();
            string tName = tOf.Name;

            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Open();
                //connection.Execute($"SET IDENTITY_INSERT [{tName}]  ON  ");
                try
                {
                    connection.Insert(results);
                }
                catch(Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                //connection.Execute($"SET IDENTITY_INSERT [{tName}]  OFF  ");
                connection.Close();
            }
        }

        static public void Update<T>(string conn, T results) where T : class
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Update<T>(results);
            }
        }

        /// <summary>
        /// Bulk Insert ADO.NET 方法，可靠速度快，10k資料量，約7.5sec Insert完成，但前置作業多放棄使用
        /// </summary>
        /// <param name="conn"></param>
        /// <param name="results"></param>
        static public void BulkInsertDataTable(string conn, DataTable results)
        {
            var tOf = results.GetType();
            string tName = tOf.Name;

            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Open();
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                {
                    bulkCopy.DestinationTableName = results.TableName;

                    try
                    {
                        // Write from the source to the destination.
                        bulkCopy.WriteToServer(results);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        throw new Exception(ex.Message);
                    }
                    finally
                    {
                        // Close the SqlDataReader. The SqlBulkCopy
                        // object is automatically closed at the end
                        // of the using block.
                        //results.Close();
                    }
                }

                //connection.Execute($"SET IDENTITY_INSERT [{tName}]  OFF  ");
                connection.Close();
            }
        }

    }


}
