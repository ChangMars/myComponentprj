﻿using Model = SqlFrameworkLibrary.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.Excute
{
    public class OeeAs
    {
        private static string connAp01_54 = Utility.Basic.connAp01_54;
        private static string connAp02 = Utility.Basic.connAp02;

        public static void InvalidCarModl(List<Model.OeeAs.OeeAsCarModl> results, string year)
        {
            // string year = dt.ToString("yyyy");
            string cmd = "UPDATE YULON_AS_CAR_MODL " +
                "SET [is_invalid] = @is_invalid, [invalid_time] = @invalid_time " +
                $"WHERE [is_invalid] <> 1 AND [year] = {year}";

            General.Excute<Model.OeeAs.OeeAsCarModl>(connAp01_54, cmd, results);
        }

        public static void InvalidCarProductivity(List<Model.OeeAs.OeeAsCarProductivity> results, string year)
        {
            // string year = dt.ToString("yyyy");
            string cmd = "UPDATE YULON_AS_CAR_PRODUCTIVITY " +
                "SET [is_invalid] = @is_invalid, [invalid_time] = @invalid_time " +
                $"WHERE [is_invalid] <> 1 AND [year] = {year}";

            General.Excute<Model.OeeAs.OeeAsCarProductivity>(connAp01_54, cmd, results);
        }

        public static void InsertCarModl(List<Model.OeeAs.OeeAsCarModl> results)
        {
            string cmd = "INSERT INTO YULON_AS_CAR_MODL(" +
                "[year]" +
                ",[big_or_small]" +
                ",[modl]" +
                ",[dst]" +
                ",[equivalent_units]" +
                ",[build_time]" +
                ",[is_invalid]" +
                //",[invalid_time] " +
                ") VALUES (" +
                "@year" +
                ",@big_or_small" +
                ",@modl" +
                ",@dst" +
                ",@equivalent_units" +
                ",@build_time" +
                ",@is_invalid" +
                //",@invalid_time " +
                "); ";

            General.Excute<Model.OeeAs.OeeAsCarModl>(connAp01_54, cmd, results);
        }

        public static void InsertCarProductivity(Model.OeeAs.OeeAsCarProductivity results)
        {
            string cmd = "INSERT INTO YULON_AS_CAR_PRODUCTIVITY(" +
                "[year]" +
                ",[jan]" +
                ",[feb]" +
                ",[mar]" +
                ",[apr]" +
                ",[may]" +
                ",[jun]" +
                ",[jul]" +
                ",[aug]" +
                ",[sep]" +
                ",[oct]" +
                ",[nov]" +
                ",[dec]" +
                ",[jan_base]" +
                ",[feb_base]" +
                ",[mar_base]" +
                ",[apr_base]" +
                ",[may_base]" +
                ",[jun_base]" +
                ",[jul_base]" +
                ",[aug_base]" +
                ",[sep_base]" +
                ",[oct_base]" +
                ",[nov_base]" +
                ",[dec_base]" +
                ",[mix_big_equvalent_units]" +
                ",[mix_small_equvalent_units]" +
                ",[build_time]" +
                ",[is_invalid]" +
                ",[invalid_time]" +
                ") VALUES (" +
                "@year" +
                ",@jan" +
                ",@feb" +
                ",@mar" +
                ",@apr" +
                ",@may" +
                ",@jun" +
                ",@jul" +
                ",@aug" +
                ",@sep" +
                ",@oct" +
                ",@nov" +
                ",@dec" +
                ",@jan_base" +
                ",@feb_base" +
                ",@mar_base" +
                ",@apr_base" +
                ",@may_base" +
                ",@jun_base" +
                ",@jul_base" +
                ",@aug_base" +
                ",@sep_base" +
                ",@oct_base" +
                ",@nov_base" +
                ",@dec_base" +
                ",@mix_big_equvalent_units" +
                ",@mix_small_equvalent_units" +
                ",@build_time" +
                ",@is_invalid" +
                ",@invalid_time" +
                "); ";

            General.Excute<Model.OeeAs.OeeAsCarProductivity>(connAp01_54, cmd, results);
        }
    }
}
