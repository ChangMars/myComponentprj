﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SqlFrameworkLibrary.Model.AskCb;

namespace SqlFrameworkLibrary.Excute
{
	public class AskCb
	{
		private static string connAp01_54 = Utility.Basic.connAp01_54;
        public static void UpdataAsk(List<YULON_AS_DEV_KWH_VALUE> results)
        {
            // string year = dt.ToString("yyyy");
            string cmd = "UPDATE YULON_AS_DEV_KWH_VALUE " +
                "SET [all_value] = @all_value, " +
                "[a1_value] = @a1_value, " +
                "[a2_value] = @a2_value, " +
                "[a3_value] = @a3_value, " +
                "[a4_value] = @a4_value, " +
                "[a5_value] = @a5_value, " +
                "[a6_value] = @a6_value, " +
                "[a7_value] = @a7_value, " +
                "[a8_value] = @a8_value, " +
                "[a9_value] = @a9_value, " +
                "[a10_value] = @a10_value, " +
                "[dttm] = @dttm " +
                "WHERE [sn] = @sn;";

            General.Excute<YULON_AS_DEV_KWH_VALUE>(connAp01_54, cmd, results);
        }

        public static int GetAskDataCount(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[YULON_AS_DEV_KWH_VALUE] ",
                            "[sn]",
                            $"[dttm] >= '{sb}' AND [dttm] < '{se}'",
                            "[sn] asc");

            return General.Query(connAp01_54, cmd).Count();
        }
    }
}
