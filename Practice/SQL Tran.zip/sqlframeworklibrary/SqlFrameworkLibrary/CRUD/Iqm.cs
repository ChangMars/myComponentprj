﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.CRUD
{
    public class Iqm
    {
        private static string connAp02 = Utility.Basic.connAp02;

        public static List<dynamic> QueryIqmOperation()
        {
            return QueryIqmOperation<dynamic>();
        }
        public static List<T> QueryIqmOperation<T>() where T : class
        {
            string cmd = General.BasicCmd("[IQM_OPERATION_BASE] ",
                            "*",
                            "",
                            "");

            return General.Query<T>(connAp02, cmd);
        }
        // -------------------------------------------------------------
        public static List<dynamic> QueryIqmRowData(DateTime dtb, DateTime dte)
        {
            return QueryIqmRowData<dynamic>(dtb, dte);
        }

        public static List<T> QueryIqmRowData<T>(DateTime dtb, DateTime dte) where T : class
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[iqm_raw_data] ",
                            "[MODEL] ,[CARNO] ,[TI_LINE] ,[OPERATION] ,[OPERATION_NAME] ,[START_TIME] ,[END_TIME], [INTERVAL_TIME]",
                            $"[START_TIME] >= '{sb}' AND [START_TIME] < '{se}'", //",
                            "case when OPERATION = 'All' then 1 else 0 end,START_TIME");

            return General.Query<T>(connAp02, cmd);
        }

        public static List<dynamic> QueryIqmRowData(string modl, string no)
        {
            return QueryIqmRowData<dynamic>(modl, no);
        }

        public static List<T> QueryIqmRowData<T>(string modl, string no) where T : class
        {
            string cmd = General.BasicCmd("[iqm_raw_data] ",
                            "[MODEL] ,[CARNO] ,[TI_LINE] ,[OPERATION] ,[OPERATION_NAME] ,[START_TIME] ,[END_TIME], [INTERVAL_TIME]",
                            $"[MODEL] = '{modl}' AND [CARNO] = '{no}'", //",
                            "case when OPERATION = 'All'then 1 else 0 end,START_TIME");

            return General.Query<T>(connAp02, cmd);
        }

        // -------------------------------------------------------------
        public static List<dynamic> QueryAsIqmSp(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            return SqlFrameworkLibrary.General.Query(connAp02, $"EXEC SP_OEE_AS_LACKOUT '{sb}', '{se}'");
        }

        public static List<dynamic> QueryAsIqm(DateTime dtb, DateTime dte, string timeCondition = "insp_time")
        {
            return QueryAsIqm(dtb, dte, "", timeCondition);
        }
        public static List<dynamic> QueryAsIqmDefault(DateTime dtb, DateTime dte)
        {
            return QueryAsIqm(dtb, dte, "AND ( [DEFECT_DESC] LIKE '%申告待補%' OR [DEFECT_DESC] LIKE '%缺件%' OR [DEFECT_DESC] LIKE '%欠品%' )", "insp_time");
        }
        public static List<dynamic> QueryAsIqm(DateTime dtb, DateTime dte, string addCondition, string timeCondition)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string whereCondition = $"[{timeCondition}] >= '{sb}' AND [{timeCondition}] < '{se}'";
            if (!string.IsNullOrEmpty(addCondition))
            {
                whereCondition += " " + addCondition;
            }
            string cmd = General.BasicCmd("IQM_YL_OEE_LOT_INSP_HIS",
                            "*",
                            whereCondition,
                            $"[{timeCondition}]");
            // 針對缺下
            // DEFECT_DESC LIKE '%申告待補%' OR DEFECT_DESC LIKE '%缺料%' OR DEFECT_DESC LIKE '%欠品% 
            return General.Query(connAp02, cmd);
        }

        public static List<dynamic> QueryAsIqm2(DateTime dtb, DateTime dte, string timeCondition = "insp_time")
        {
            return QueryAsIqm2(dtb, dte, "", timeCondition);
        }
        public static List<dynamic> QueryAsIqmDefault2(DateTime dtb, DateTime dte)
        {
            return QueryAsIqm2(dtb, dte, "AND ( [DEFECT_DESC] LIKE '%申告待補%' OR [DEFECT_DESC] LIKE '%缺%' OR [DEFECT_DESC] LIKE '%欠%' )", "insp_time");
        }
        public static List<dynamic> QueryAsIqm2(DateTime dtb, DateTime dte, string addCondition, string timeCondition)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string whereCondition = $"[{timeCondition}] >= '{sb}' AND [{timeCondition}] < '{se}'";
            if (!string.IsNullOrEmpty(addCondition))
            {
                whereCondition += " " + addCondition;
            }
            string cmd = General.BasicCmd("IQM_YL_OEE_MAT_SHORTAGE",
                            "*",
                            whereCondition,
                            $"[{timeCondition}]");
            // 針對缺下
            // DEFECT_DESC LIKE '%申告待補%' OR DEFECT_DESC LIKE '%缺料%' OR DEFECT_DESC LIKE '%欠品% 
            return General.Query(connAp02, cmd);
        }



        public static List<dynamic> QueryAsIqm(string modl, string no)
        {
            //string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            //string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            //string whereCondition = $"[insp_time] >= '{sb}' AND [insp_time] < '{se}'";
            //if (!string.IsNullOrEmpty(addCondition))
            //{
            //    whereCondition += " " + addCondition;
            //}
            string cmd = General.BasicCmd("IQM_YL_OEE_LOT_INSP_HIS",
                            "[MODEL], [CARNO], [OPERATION], [START_TIME], [END_TIME], [DEFECT_DESC], [FIX_TIME], [FIX_OPERATION]",
                            $"[MODEL] = '{modl}' and [CARNO] = '{no}'",
                            "[insp_time]");
            // 針對缺下
            // DEFECT_DESC LIKE '%申告待補%' OR DEFECT_DESC LIKE '%缺料%' OR DEFECT_DESC LIKE '%欠品% 
            return General.Query(connAp02, cmd);
        }

        public static List<dynamic> QueryAsIqm2(string modl, string no)
        {
            //string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            //string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            //string whereCondition = $"[insp_time] >= '{sb}' AND [insp_time] < '{se}'";
            //if (!string.IsNullOrEmpty(addCondition))
            //{
            //    whereCondition += " " + addCondition;
            //}
            string cmd = General.BasicCmd("IQM_YL_OEE_MAT_SHORTAGE",
                            "[MODEL], [CARNO], [OPERATION], [INSP_TIME], [FIX_TIME], [DEFECT_DESC], [FIX_TIME], [FIX_OPERATION]",
                            $"[MODEL] = '{modl}' and [CARNO] = '{no}'",
                            "[insp_time]");
            // 針對缺下
            // DEFECT_DESC LIKE '%申告待補%' OR DEFECT_DESC LIKE '%缺料%' OR DEFECT_DESC LIKE '%欠品% 
            return General.Query(connAp02, cmd);
        }

        //-------------------------------------------
        public static List<dynamic> QueryMvrRecord(DateTime dtb, DateTime dte)
        {
            return QueryMvrRecord<dynamic>(dtb, dte);
        }

        public static List<T> QueryMvrRecord<T>(DateTime dtb, DateTime dte) where T : class
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[MVR_YL_DPM_PROD_REPORT_V] ",
                            "*",
                            $"[DATA_DATE] >= '{sb}' AND [DATA_DATE] < '{se}'",
                            "[DATA_DATE] asc");

            return General.Query<T>(connAp02, cmd);
        }

        // ----------------------------------------------------------------------------------------
        public static List<dynamic> QueryPartHis(DateTime dtb, DateTime dte, string addCondition = "")
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string whereCondition = $"[UPDATE_TIME] >= '{sb}' AND [UPDATE_TIME] < '{se}' AND [CKPT_ID] = 'P/O' AND [LINE_CODE] = 'A2'";
            if (!string.IsNullOrEmpty(addCondition))
            {
                whereCondition += " " + addCondition;
            }

            string cmd = General.BasicCmd("[PARTS_HIS]",
                            "TOP (1) [UPDATE_TIME] ,[LINE_CODE] ,[CKPT_ID] ,[TOTAL] ,[R] ,[Y] ,[G]",
                            whereCondition,
                            "[UPDATE_TIME] desc");
            return General.Query(connAp02, cmd);
        }
    }
}
