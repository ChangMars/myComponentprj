﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.CRUD
{
    public class Bind
    {
        //private static string connAp01_54 = Utility.Basic.connAp01_54;
        private static string connAp01_54 = Utility.Basic.connAp01_54;
        //private static string connAp02 = Utility.Basic.connAp02;

        public static List<dynamic> QueryBindSpcAlcEngn(DateTime dtb, DateTime dte)
        {
            return QueryBindSpcAlcEngn<dynamic>(dtb, dte);
        }

        public static List<T> QueryBindSpcAlcEngn<T>(DateTime dtb, DateTime dte) where T : class 
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[YULON_BIND_SPC_ALC_ENGN] ",
                            "*",
                            $"[eo_dttm] >= '{sb}' AND [eo_dttm] < '{se}'",
                            "[eo_dttm] asc");

            return General.Query<T>(connAp01_54, cmd);
        }

        public static List<dynamic> QueryBindSpcEpmRecord(DateTime dtb, DateTime dte)
        {
            return QueryBindSpcAlcEngn<dynamic>(dtb, dte);
        }

        public static List<T> QueryBindSpcEpmRecord<T>(DateTime dtb, DateTime dte) where T : class
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[YULON_BIND_SPC_ENG_EPM_RECORD] ",
                            "*",
                            $"[eo_dttm] >= '{sb}' AND [eo_dttm] < '{se}'",
                            "[eo_dttm] asc");

            return General.Query<T>(connAp01_54, cmd);
        }

        public static List<dynamic> QueryBindAlcEmdlSpcPara()
        {
            return QueryBindAlcEmdlSpcPara<dynamic>();
        }

        public static List<T> QueryBindAlcEmdlSpcPara<T>() where T : class
        {
            string cmd = General.BasicCmd("[YULON_BIND_ALC_SPC_PARA] ",
                            "*",
                            "",
                            "[equip_no], [emdl] asc");

            return General.Query<T>(connAp01_54, cmd);
        }

        public static List<T> QueryBindCiSiData<T>(DateTime dtb, DateTime dte, string section = "") where T : class
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string contidion = $"[DateTime] >= '{sb}' AND [DateTime] < '{se}'";
            if (!string.IsNullOrEmpty(section))
                contidion += $" AND [Section] = '{section}'";

            string cmd = General.BasicCmd("[YULON_BIND_CI_SI_DATA] ",
                            "*",
                            contidion,
                            "[DateTime] asc");

            return General.Query<T>(connAp01_54, cmd);
        }

        public static List<T> QueryBindCiSiCar<T>(DateTime dtb, DateTime dte) where T : class
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string contidion = $"[DateTime] >= '{sb}' AND [DateTime] < '{se}'";

            string cmd = General.BasicCmd("[YULON_BIND_CI_SI_CAR] ",
                            "*",
                            contidion,
                            "[DateTime] asc");

            return General.Query<T>(connAp01_54, cmd);
        }


        public static List<dynamic> QueryBindPaintClearSames(DateTime dtb, DateTime dte)
        {
            return QueryBindPaintClearSames<dynamic>(dtb, dte);
        }

        public static List<TSource> QueryBindPaintClearSames<TSource>(DateTime dtb, DateTime dte) where TSource : class
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[YULON_BIND_PAINT_CLEAR_SAMES] ",
                            "*",
                            $"[eo_dttm] >= '{sb}' AND [eo_dttm] < '{se}'",
                            "[eo_dttm] asc");

            return General.Query<TSource>(connAp01_54, cmd);
        }
    }
}
