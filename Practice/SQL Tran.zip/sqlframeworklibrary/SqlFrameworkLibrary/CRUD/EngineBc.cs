﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.CRUD
{
    public class EngineBc
    {
        private static string connEgBc = Utility.Basic.connEngineBC;

        public static void UpdateEgBc(List<Model.EngineBc.TorqueFrontCoverWithId> results)
        {
            
            string cmd = "UPDATE [BC_DataRecord].[dbo].[Torque_FrontCover] " +
            #region
                "SET " +
                "[Count] = @Count, " +
                "[T1] = @T1, " +
                "[T2] = @T2, " +
                "[T3] = @T3, " +
                "[T4] = @T4, " +
                "[T5] = @T5, " +
                "[T6] = @T6, " +
                "[T7] = @T7, " +
                "[T8] = @T8, " +
                "[T9] = @T9, " +
                "[T10] = @T10, " +
                "[T11] = @T11, " +
                "[T12] = @T12, " +
                "[T13] = @T13, " +
                "[T14] = @T14, " +
                "[T15] = @T15, " +
                "[T16] = @T16, " +
                "[T17] = @T17, " +
                "[T18] = @T18, " +
                "[T19] = @T19, " +
                "[T20] = @T20, " +
                "[T21] = @T21, " +
                "[T22] = @T22, " +
                "[T23] = @T23, " +
                "[T24] = @T24, " +
                "[T25] = @T25, " +
                "[T26] = @T26, " +
                "[T27] = @T27, " +
                "[T28] = @T28, " +
                "[T29] = @T29, " +
                "[T30] = @T30, " +
                "[T31] = @T31, " +
                "[T32] = @T32, " +
                "[T33] = @T33, " +
                "[T34] = @T34, " +
                "[T35] = @T35, " +
                "[T36] = @T36, " +
                "[T37] = @T37, " +
                "[T38] = @T38, " +
                "[T39] = @T39, " +
                "[T40] = @T40, " +
                "[T41] = @T41, " +
                "[T42] = @T42, " +
                "[T43] = @T43, " +
                "[T44] = @T44, " +
                "[T45] = @T45, " +
                "[T46] = @T46, " +
                "[T47] = @T47, " +
                "[T48] = @T48, " +
                "[T49] = @T49, " +
                "[T50] = @T50 " +
                "WHERE [No] = @No";
            #endregion

            General.Excute<Model.EngineBc.TorqueFrontCoverWithId>(connEgBc, cmd, results);
        }

        public static void InsertEgBc(List<Model.EngineBc.TorqueFrontCoverWithId> results)
        {
            // string year = dt.ToString("yyyy");
            //string cmd = "INSERT INTO [BC_DataRecord].[dbo].[Torque_FrontCover] ([engn_no],[eng_Type],[Count],[T1],[T2],[T3],[T4],[T5],[T6],[T7],[T8],[T9],[T10],[T11],[T12],[T13],[T14],[T15],[T16],[T17],[T18],[T19],[T20],[T21],[T22],[T23],[T24],[T25],[T26],[T27],[T28],[T29],[T30],[T31],[T32],[T33],[T34],[T35],[T36],[T37],[T38],[T39],[T40],[T41],[T42],[T43],[T44],[T45],[T46],[T47],[T48],[T49],[T50],[DataRecord],[Comment])" +
            //    "VALUES(@engn_no,@eng_Type,@Count,@T1,@T2,@T3,@T4,@T5,@T6,@T7,@T8,@T9,@T10,@T11,@T12,@T13,@T14,@T15,@T16,@T17,@T18,@T19,@T20,@T21,@T22,@T23,@T24,@T25,@T26,@T27,@T28,@T29,@T30,@T31,@T32,@T33,@T34,@T35,@T36,@T37,@T38,@T39,@T40,@T41,@T42,@T43,@T44,@T45,@T46,@T47,@T48,@T49,@T50,@DataRecord,@Comment)";

            //General.Excute<Model.EngineBc.TorqueFrontCoverWithId>(connEgBc, cmd, results);

            Extension.BulkInsert(connEgBc, results);
        }

        public static List<dynamic> QueryTorqueFrontCoverWithId(DateTime dtb, DateTime dte)
        {
            return QueryTorqueFrontCoverWithId<dynamic>(dtb, dte);
        }

        public static List<T> QueryTorqueFrontCoverWithId<T>(DateTime dtb, DateTime dte) where T : class
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[Torque_FrontCover] ",
                            "*",
                            $"[DataRecord] >= '{sb}' AND [DataRecord] < '{se}'",
                            "[DataRecord] asc");

            return General.Query<T>(connEgBc, cmd);
        }
    }
}
