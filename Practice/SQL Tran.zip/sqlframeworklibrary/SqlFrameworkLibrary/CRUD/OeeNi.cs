﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.CRUD
{
	public class OeeNi
	{
		public static string connAp01 = Utility.Basic.connAp01_54;
        public static string connAp02 = Utility.Basic.connAp02;
        public static string connAp03 = Utility.Basic.connAp03;
        /// <summary>
        /// 車身場NIMS線設備資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryNIMS_SIGNAL(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");
            //改
            string cmd = "SELECT [dttm]'RQ',[tag_line_id],[tag_name_chn]'type'," +
                "CAST(isnull([1],0) AS BIT)'op1',CAST(isnull([2],0) AS BIT)'op2',CAST(isnull([3],0) AS BIT)'op3',CAST(isnull([4],0) AS BIT)'op4'," +
                "CAST(isnull([5],0) AS BIT)'op5',CAST(isnull([6],0) AS BIT)'op6',CAST(isnull([7],0) AS BIT)'op7',CAST(isnull([8],0) AS BIT)'op8'," +
                "CAST(isnull([9],0) AS BIT)'op9',CAST(isnull([10],0) AS BIT)'op10',CAST(isnull([11],0) AS BIT)'op11',CAST(isnull([12],0) AS BIT)'op12'," +
                "CAST(isnull([13],0) AS BIT)'op13',CAST(isnull([14],0) AS BIT)'op14',CAST(isnull([15],0) AS BIT)'op15',CAST(isnull([16],0) AS BIT)'op16'," +
                "CAST(isnull([17],0) AS BIT)'op17',CAST(isnull([18],0) AS BIT)'op18',CAST(isnull([19],0) AS BIT)'op19',CAST(isnull([20],0) AS BIT)'op20'," +
                "CAST(isnull([21],0) AS BIT)'op21',CAST(isnull([22],0) AS BIT)'op22',CAST(isnull([23],0) AS BIT)'op23',CAST(isnull([24],0) AS BIT)'op24'," +
                "CAST(isnull([25],0) AS BIT)'op25',CAST(isnull([26],0) AS BIT)'op26',CAST(isnull([27],0) AS BIT)'op27',CAST(isnull([28],0) AS BIT)'op28',CAST(isnull([30],0) AS BIT)'op29' " +
                "FROM (SELECT [dttm],CAST([tag_value] AS TINYINT)[tag_value],B.[tag_line_id],B.[tag_operation_num],B.[tag_name_chn] FROM[APDB03].[dbo].[MODBUS_RECEIVER_BIT] A, [APDB03].[dbo].[MODBUS_TAG] B " +
                "where A.tag_num = B.tag_num "+
                $"AND A.dttm BETWEEN '{sb}' AND '{se}' AND B.[tag_line_id] IN ('N') AND B.factory = '車身場' " +
                "AND B.tag_name_chn LIKE '%[極頭研磨運轉故障緊急停止]%') D  PIVOT(MAX(tag_value) FOR tag_operation_num IN([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12],[13],[14],[15],[16],[17],[18],[19],[20],[21],[22],[23],[24],[25],[26],[27],[28],[30]) ) P ORDER BY dttm";
            return General.Query(connAp03, cmd);
        }

        /// <summary>
        /// 車身場NIMS線ALC資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryTB_NIMS_V(DateTime dtb, DateTime dte, string Name, string Dttm1, string Dttm2, string Num)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");
            string cmd = "";
            //and ([special_code] is null or [special_code] != 'X') //過濾試作車 20211015 取消
            if (Dttm2 == "bo_dttm")
            {
                //cmd = $"SELECT '{Dttm1}'[LINE],[{Dttm1}][TIME]  FROM [APDB01].[dbo].[YULON_AS_ALC] " +
                //    $"WHERE [{Dttm1}] >= '{sb}' AND [{Dttm1}] < '{se}'" + //通過量
                //    $"UNION ALL SELECT '{Dttm2}'[LINE],[{Dttm2}][TIME]  FROM [APDB01].[dbo].[YULON_AS_ALC] " +
                //    $"WHERE [{Dttm2}] >= '{sb}' AND [{Dttm2}] < '{se}'"; //整修通過量

                cmd = $"SELECT '{Dttm2}'[LINE],[{ Dttm2}][TIME]  FROM[APDB01].[dbo].[YULON_AS_ALC] " +
                    $"WHERE [{Dttm2}] >= '{sb}' AND [{Dttm2}] < '{se}' and left(modl,3) in ('P15','C12','B18','P33') AND ([wi_line] = 4 or [wi_line] is null)"; //
            }
            else
            {
                cmd = $"SELECT '{Dttm1}'[LINE],[{Dttm1}][TIME]  FROM [APDB01].[dbo].[YULON_AS_ALC] " +
                    $"WHERE [{Dttm1}] >= '{sb}' AND [{Dttm1}] < '{se}' and left(modl,3) in ('P15','C12','B18','P33') AND ([wi_line] = 4 or [wi_line] is null)"; //通過量 

            }
			return General.Query(connAp01, cmd);
        }
        /// <summary>
        /// 車身場NIMS線RCO線邊資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryRCOOFFLINECAR(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");
            //Transactiontime,Reasondescr,車身檢查站,""
            //and ([special_code] is null or [special_code] != 'X') //過濾試作車 20211015 取消
            string cmd = "SELECT *  FROM [APDB01].[dbo].[YULON_CB_OFFLINECAR] " +
                $"WHERE  left(MODEL,3) in ('P15','C12','B18','P33') and ([ON_TIME] is null or [ON_TIME] > '{sb}') and [OFF_TIME] < '{se}' ";
            return General.Query(connAp01, cmd);
        }
        /// <summary>
        /// 車身場NIMS線異常工單資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryYULON_AS_ERROR_HISTORY(DateTime dtb, DateTime dte,int index)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");
            string line = index == 16 ? "工藝一段" : "工藝二段";
            string cmd = "SELECT time_star,msg_reason,sys_pcs,sys_minute,msg_car_part,sys_real,msg_inspection FROM [APDB01].[dbo].[YULON_AS_ERROR_HISTORY] " +
                $"WHERE factory = '車身場' and line = '{line}' and sys_autotype ='空格損失' and RQ between '{sb}' and '{se}' and is_visible = 1 ";
            return General.Query(connAp01, cmd);
        }

        /// <summary>
        /// 車身場NIMS線IQM Q類損失資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryIQM(DateTime dtb, DateTime dte, string sn)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");
            //Transactiontime,Reasondescr,車身檢查站,""
            string cmd = "SELECT [TRANSACTIONTIME][DATE],[CAR] = [MODEL]+' '+[CHS_NO],[AREACATEGORYITEMNAME],[REASONDESCR],[DUTY_DEPT_NAME],[OPERATION]='車身檢查站' FROM [APDB01].[dbo].[YULON_BIND_IQM_PAINT_DEFECT]" +
                $"WHERE LINE = '{sn}' AND [TRANSACTIONTIME] > '{sb}' AND [TRANSACTIONTIME] < '{se}' and left(MODEL,3) in ('P15','C12','B18','P33')";
            return General.Query(connAp01, cmd);
        }

        /// <summary>
        /// 車身場NIMS線用電資料資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryAsKwhFnc(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");
            //
            string cmd = "SELECT [dttm],[407]'a407',[412]'a412',[421]'a421',[422]'a422',[423]'a423',[426]'a426',[430]'a430',[431]'a431',[432]'a432',[433]'a433',[434]'a434' FROM(" +
                "SELECT [dttm],[tag_num],[tag_value] FROM [APDB03].[dbo].[MODBUS_RECEIVER_VALUE]" +
                $"WHERE [dttm] BETWEEN '{sb}' AND '{se}' AND [tag_num] in (" +
                "SELECT [tag_num] FROM [APDB03].[dbo].[MODBUS_TAG] WHERE [factory] = '車身場' AND [zone] = 'Ring1' AND [tag_name_chn] = '用電度數')" +
                ") source PIVOT (" +
                "MAX(tag_value) FOR tag_num IN([407],[412],[421],[422],[423],[426],[430],[431],[432],[433],[434])" +
                ") result ORDER BY dttm";
            return General.Query(connAp01, cmd);
        }


        //改
        public static List<dynamic> QueryAPDB02Mo(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");
            //
            string cmd = $" EXEC[APDB02_GetWI_PLAN_A] '{sb}','{se}'";
            return General.Query(connAp02, cmd);
        }
    }
}
