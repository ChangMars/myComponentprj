﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.CRUD
{
    public class Spc
    {
        private static string connSpc = Utility.Basic.connSpc;

        public static List<dynamic> QuerySpcAlcEngn()
        {
            
            string cmd = General.BasicCmd("[v_alc_engn] ",
                            "*",
                            "",
                            "");

            return General.Query(connSpc, cmd);
        }

        public static List<dynamic> QuerySpcEngEpm()
        {
            string str = "EM-11";
            string cmd = General.BasicCmd("[v_ENG_EPM_Record] ",
                            "*",
                            $"[Equipment_No] <> '{str}'",
                            "");

            return General.Query(connSpc, cmd);
        }
    }
}
