﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.CRUD
{
    public class Qrac
    {
        private static string connAp02 = Utility.Basic.connAp02;
    }
}
