﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.CRUD
{
    public class Alc
    {
        private static string connAlcSa = Utility.Basic.connAlcSa;
        private static string connAlc = Utility.Basic.connAlc;

        public static List<dynamic> QueryAlcModlLineId()
        {
            string cmd = General.BasicCmd("[sers] ",
                            "*",
                            "",
                            "");

            return General.Query(connAlcSa, cmd);
        }

        public static List<dynamic> QueryAlcEmdlSpcPara()
        {
            return QueryAlcEmdlSpcPara<dynamic>();
        }

        public static List<T> QueryAlcEmdlSpcPara<T>() where T : class
        {
            string cmd = General.BasicCmd("[emdl_spc_para] ",
                            "*",
                            "",
                            "");

            return General.Query<T>(connAlc, cmd);
        }
    }
}
