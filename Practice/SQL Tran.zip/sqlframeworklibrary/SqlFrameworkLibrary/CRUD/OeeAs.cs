﻿using Model = SqlFrameworkLibrary.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.CRUD
{
    public class OeeAs
    {
        private static string connAp01_54 = Utility.Basic.connAp01_54;
        //private static string connAp01 = Utility.Basic.connAp01;
        private static string connAp02 = Utility.Basic.connAp02;

        public static List<dynamic> QueryOeeTarg(DateTime dt, string factory, string zone = "-", string line = "-")
        {
            string s = dt.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[YULON_OEE_TARGET] ",
                            "*",
                            $"[factory] = '{factory}' and [zone] = '{zone}' and [line] = '{line}' and [create_time] < '{s}'",
                            "[create_time] asc");

            return General.Query(connAp01_54, cmd);
        }

        public static List<dynamic> QueryAsKwhReal(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[YULON_AS_NYKB] ",
                            "[RQ],[SJ] ,[車裝工場_累計1_0_0_0] AS gcb, " +
                            "[組裝線_累計1_1_0_0] AS acb1, [P11升降機_累計1_1_1_1] AS acb2 ," +
                            "[P1升降機_累計1_1_1_2] AS acb3 ,[高空輸送鏈條_累計1_1_1_3] AS acb4 ," +
                            "[輪胎線_累計1_1_2_0] AS acb5 , [新底盤系統_累計1_1_3_0] AS acb6 ," +
                            "[a_累計] AS t2 , [b_累計] AS else2 ," +
                            "[c_累計] AS else3 , [d_累計] AS else4",
                            $"[RQ] >= '{sb}' AND [RQ] < '{se}'",
                            "[RQ] asc");

            return General.Query(connAp01_54, cmd);
        }

        public static List<dynamic> QueryAsKwhReal_54(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[YULON_AS_NYKB] ",
                            "[RQ],[SJ] ,[車裝工場_累計1_0_0_0] AS gcb, " +
                            "[組裝線_累計1_1_0_0] AS acb1, [P11升降機_累計1_1_1_1] AS acb2 ," +
                            "[P1升降機_累計1_1_1_2] AS acb3 ,[高空輸送鏈條_累計1_1_1_3] AS acb4 ," +
                            "[輪胎線_累計1_1_2_0] AS acb5 , [新底盤系統_累計1_1_3_0] AS acb6 ," +
                            "[a_累計] AS t2 , [b_累計] AS else2 ," +
                            "[c_累計] AS else3 , [d_累計] AS else4",
                            $"[RQ] >= '{sb}' AND [RQ] < '{se}'",
                            "[RQ] asc");

            return General.Query(connAp01_54, cmd);
        }

        public static List<dynamic> QueryAsModbus(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("YULON_AS_Modbus",
                            "*",
                            $"[RQ] >= '{sb}' AND [RQ] < '{se}'",
                            "[RQ]");
            return General.Query(connAp01_54, cmd);
        }

        public static List<dynamic> QueryAsDayRecord(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd");
            string se = dte.ToString("yyyy/MM/dd");

            string cmd = General.BasicCmd("YULON_AS_DAY_RECORD",
                            "*",
                            $"[RQ] >= '{sb}' AND [RQ] <= '{se}'",
                            "[RQ]");
            return General.Query(connAp01_54, cmd);
        }

        public static List<YULON_AS_DAY_RECORD> QueryAsDayRecord<YULON_AS_DAY_RECORD>(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd");
            string se = dte.ToString("yyyy/MM/dd");

            string cmd = General.BasicCmd("YULON_AS_DAY_RECORD",
                            "*",
                            $"[RQ] >= '{sb}' AND [RQ] <= '{se}'",
                            "[RQ]");
            return General.Query<YULON_AS_DAY_RECORD>(connAp01_54, cmd);
        }

        public static List<YULON_AS_DAY_RECORD> QueryAsDayRecord<YULON_AS_DAY_RECORD>(DateTime dtb, DateTime dte, string factory, string zone)
        {
            string sb = dtb.ToString("yyyy/MM/dd");
            string se = dte.ToString("yyyy/MM/dd");

            string cmd = General.BasicCmd("YULON_AS_DAY_RECORD",
                            "*",
                            $"[RQ] >= '{sb}' AND [RQ] <= '{se}' AND [factory] = '{factory}' AND [zone] = '{zone}'",
                            "[RQ]");
            return General.Query<YULON_AS_DAY_RECORD>(connAp01_54, cmd);
        }

        /// <summary>
        /// Query CCR Predict Car Line
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<Model.OeeAs.OeeAsCcrPrdt> QueryCcrPrdt(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd 00:00:00");
            string se = dte.ToString("yyyy/MM/dd 23:59:59");

            string cmd = General.BasicCmd("YULON_AS_CCR_PRDT ",
                            "DISTINCT [modl] + [chs_no] AS [modl_chs_no], [car_qty], [modl], [ccr_prdt_dttm] ",
                            $"[RQ] >= '{sb}' AND [RQ] < '{se}'",
                            "[car_qty] asc");

            // 為了排序特別處理
            var ccrPrdtDst = General.Query<Model.OeeAs.OeeAsCcrPrdt>(connAp01_54, cmd);
            var qtyNull = ccrPrdtDst.FindAll(x => x.car_qty is null);
            var qtyNum = ccrPrdtDst.FindAll(x => x.car_qty != null);
            qtyNum.AddRange(qtyNull);

            return qtyNum;
        }

        public static List<dynamic> QueryCcrPrdtDynamic(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd 00:00:00");
            string se = dte.ToString("yyyy/MM/dd 23:59:59");

            string cmd = General.BasicCmd("YULON_AS_CCR_PRDT ",
                            "DISTINCT [modl] + [chs_no] AS [modl_chs_no], [car_qty], [modl], [ccr_prdt_dttm] ",
                            $"[RQ] >= '{sb}' AND [RQ] < '{se}'",
                            "[car_qty] asc");

            // 為了排序特別處理
            var ccrPrdtDst = General.Query(connAp01_54, cmd);
            var qtyNull = ccrPrdtDst.FindAll(x => x.car_qty is null);
            var qtyNum = ccrPrdtDst.FindAll(x => x.car_qty != null);
            qtyNum.AddRange(qtyNull);

            return qtyNum;
        }

        public static List<dynamic> QueryAsPlc(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd 00:00:00");
            string se = dte.ToString("yyyy/MM/dd 23:59:59");

            string cmdd = General.BasicCmd("YULON_AS_PLC ",
                            "*",
                            $"[RQ] >= '{sb}' AND [RQ] < '{se}'",
                            "");

            return General.Query(connAp01_54, cmdd);  
        }

        /// <summary>
        /// Query ALC Actural Car Line
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryAsAlc(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("YULON_AS_ALC",
                            "*",
                            $"[ti_dttm] >= '{sb}' AND [ti_dttm] < '{se}'",
                            "[ti_dttm]");
            return General.Query(connAp01_54, cmd);
        }
        //2021/10/27 為進版更新查詢位置
        public static List<dynamic> QueryAsAlcCalendar(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd 00:00:00");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("YULON_AS_CALENDAR_NEW",
                            "*",
                            $"[begn_dttm] >= '{sb}' AND [begn_dttm] < '{se}'",
                            "[begn_dttm]");
            return General.Query(connAp01_54, cmd);
        }

        public static List<Model.OeeAs.OeeAsCarModl> QueryCarModl(string year)
        {
            string cmd = General.BasicCmd("YULON_AS_CAR_MODL",
                            "*",
                            $"[is_invalid] <> 1 AND [year] = '{year}'",
                            "sn");
            return General.Query<Model.OeeAs.OeeAsCarModl>(connAp01_54, cmd);
        }

        public static List<Model.OeeAs.OeeAsCarProductivity> QueryAsCarProductivity(string year, string factory, string zone)
        {
            string cmd = General.BasicCmd("YULON_AS_CAR_PRODUCTIVITY",
                    "*",
                   $"[is_invalid] <> 1 AND [year] = '{year}' AND [factory] = '{factory}' AND [zone] = '{zone}'",
                    "");
            return General.Query<Model.OeeAs.OeeAsCarProductivity>(connAp01_54, cmd);
        }

        public static List<dynamic> QueryAsDevKwhPara(string factory, string zone)
        {
            return QueryAsDevKwhPara<dynamic>(factory, zone);
        }

        public static List<T> QueryAsDevKwhPara<T>(string factory, string zone) where T : class
        {
            string cmd = General.BasicCmd("[YULON_AS_DEV_KWH_PARA] ",
                            "*",
                            $"([is_invalid] = 0 OR [is_invalid] is null) AND [factory] = '{factory}' AND [zone] = '{zone}'",
                            "");

            return General.Query<T>(connAp01_54, cmd);
        }

        // ----------------------------------------------------------------------------------------
        public static List<dynamic> QueryFuncNg(DateTime dtb, DateTime dte)
        {
            return QueryFuncNg(dtb, dte, "");
        }
        public static List<dynamic> QueryFuncNgDefault(DateTime dtb, DateTime dte)
        {
            return QueryFuncNg(dtb, dte, "AND [RESULT] = 'NG'");
        }
        public static List<dynamic> QueryFuncNg(DateTime dtb, DateTime dte, string addCondition)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string whereCondition = $"[CREATE_TIME] >= '{sb}' AND [CREATE_TIME] < '{se}'";
            if (!string.IsNullOrEmpty(addCondition))
            {
                whereCondition += " " + addCondition;
            }

            string cmd = General.BasicCmd("[YULON_AS_TestinLine]",
                            "*",
                            whereCondition,
                            "[CREATE_TIME]");
            return General.Query(connAp01_54, cmd);
        }

        public static List<dynamic> QueryFuncNgDetail(DateTime dtb, DateTime dte, string addCondition)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string whereCondition = $"[time_final] >= '{sb}' AND [time_final] < '{se}'";
            if (!string.IsNullOrEmpty(addCondition))
            {
                whereCondition += " " + addCondition;
            }

            string cmd = General.BasicCmd("[YULON_AS_TESTINLINE_DETAIL]",
                            "*",
                            whereCondition,
                            "[time_final]");
            return General.Query(connAp01_54, cmd);
        }

        public static List<dynamic> QueryFuncNgDetailDefault(DateTime dtb, DateTime dte)
        {
            return QueryFuncNgDetail(dtb, dte, "AND [result] = '退重電整修'");
        }

        // ----------------------------------------------------------------------------------------
        public static List<dynamic> QueryRfNext(DateTime dtb, DateTime dte)
        {
            return QueryRfNext(dtb, dte, "");
        }
        public static List<dynamic> QueryRfNextDefault(DateTime dtb, DateTime dte)
        {
            return QueryRfNext(dtb, dte, "AND [NEXT_OPERATION] = 'ImportantElec'");
        }

        public static List<dynamic> QueryRfNext(DateTime dtb, DateTime dte, string addCondition)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string whereCondition = $"[UPDATE_TIME] >= '{sb}' AND [UPDATE_TIME] < '{se}'";
            if (!string.IsNullOrEmpty(addCondition))
            {
                whereCondition += " " + addCondition;
            }

            string cmd = General.BasicCmd("YULON_AS_RFNext",
                            "*",
                            whereCondition,
                            "[UPDATE_TIME]");
            return General.Query(connAp01_54, cmd);
        }
        // ----------------------------------------------------------------------------------------
        //public static List<dynamic> QueryAsIqm(DateTime dtb, DateTime dte)
        //{
        //    return QueryAsIqm(dtb, dte, "");
        //}
        //public static List<dynamic> QueryAsIqmDefault(DateTime dtb, DateTime dte)
        //{
        //    return QueryAsIqm(dtb, dte, "AND [MODEL] not like 'L92%' AND ( [DEFECT_DESC] LIKE '%申告待補%' OR [DEFECT_DESC] LIKE '%缺件%' OR [DEFECT_DESC] LIKE '%欠品%' )");
        //}
        //public static List<dynamic> QueryAsIqm(DateTime dtb, DateTime dte, string addCondition)
        //{
        //    string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
        //    string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

        //    string whereCondition = $"[insp_time] >= '{sb}' AND [insp_time] < '{se}'";
        //    if (!string.IsNullOrEmpty(addCondition))
        //    {
        //        whereCondition += " " + addCondition;
        //    }
        //    string cmd = General.BasicCmd("IQM_YL_OEE_LOT_INSP_HIS",
        //                    "*",
        //                    whereCondition,
        //                    "[insp_time]");
        //    // 針對缺下
        //    // DEFECT_DESC LIKE '%申告待補%' OR DEFECT_DESC LIKE '%缺料%' OR DEFECT_DESC LIKE '%欠品% 
        //    return General.Query(connAp02, cmd);
        //}

        //public static List<dynamic> QueryAsIqm2(DateTime dtb, DateTime dte)
        //{
        //    return QueryAsIqm2(dtb, dte, "");
        //}
        //public static List<dynamic> QueryAsIqmDefault2(DateTime dtb, DateTime dte)
        //{
        //    return QueryAsIqm2(dtb, dte, "AND [MODEL] not like 'L92%' AND ( [DEFECT_DESC] LIKE '%申告待補%' OR [DEFECT_DESC] LIKE '%缺%' OR [DEFECT_DESC] LIKE '%欠%' )");
        //}
        //public static List<dynamic> QueryAsIqm2(DateTime dtb, DateTime dte, string addCondition)
        //{
        //    string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
        //    string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

        //    string whereCondition = $"[insp_time] >= '{sb}' AND [insp_time] < '{se}'";
        //    if (!string.IsNullOrEmpty(addCondition))
        //    {
        //        whereCondition += " " + addCondition;
        //    }
        //    string cmd = General.BasicCmd("IQM_YL_OEE_MAT_SHORTAGE",
        //                    "*",
        //                    whereCondition,
        //                    "[insp_time]");
        //    // 針對缺下
        //    // DEFECT_DESC LIKE '%申告待補%' OR DEFECT_DESC LIKE '%缺料%' OR DEFECT_DESC LIKE '%欠品% 
        //    return General.Query(connAp02, cmd);
        //}

        

        // ----------------------------------------------------------------------------------------
        public static List<dynamic> QueryAsErrorHistory(DateTime dtb, DateTime dte)
        {
            return QueryAsErrorHistory<dynamic>(dtb, dte);
        }

        public static List<T> QueryAsErrorHistory<T>(DateTime dtb, DateTime dte) where T : class
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[YULON_AS_ERROR_HISTORY] ",
                            "*",
                            $"[RQ] >= '{sb}' AND [RQ] <= '{se}'",
                            "[RQ], [SJ]");

            return General.Query<T>(connAp01_54, cmd);
        }

        public static List<dynamic> QueryAsErrorHistory(int sn)
        {
            return QueryAsErrorHistory<dynamic>(sn);
        }

        public static List<T> QueryAsErrorHistory<T>(int sn) where T : class
        {
            string cmd = General.BasicCmd("[YULON_AS_ERROR_HISTORY] ",
                            "*",
                            $"[sn] = {sn}",
                            "[RQ], [SJ]");

            return General.Query<T>(connAp01_54, cmd);
        }
        public static List<dynamic> QueryAsResponseDepartment(string factory, string zone)
        {
            string cmd = General.BasicCmd("[YULON_AS_RESPONSE_DEPARTMENT]",
                            "*",
                            $"[factory] = '{factory}' AND [zone] = '{zone}'",
                            "");
            return General.Query(connAp01_54, cmd);
        }

        public static List<dynamic> QueryAsResponseDepartment()
        {
            string cmd = General.BasicCmd("[YULON_AS_RESPONSE_DEPARTMENT]",
                            "*",
                            "",
                            "");
            return General.Query(connAp01_54, cmd);
        }

        public static List<dynamic> QueryAsErrorRelate(string factory = "", string zone = "")
        {
            string whereCondition = "";
            if (factory != "")
                whereCondition += $"[factory] = '{factory}' ";
            if (zone != "")
            {
                if (whereCondition != "")
                    whereCondition += "AND ";
                whereCondition += $"[zone] = '{zone}'";
            }

            string cmd = General.BasicCmd("[YULON_AS_ERROR_RELATE]",
                            "*",
                            whereCondition,
                            "");

            return General.Query(connAp01_54, cmd);
        }

        //public static List<dynamic> QueryEgErrorHistory(DateTime dt1, DateTime dt2)
        //{
        //    string cmd = General.BasicCmd("[YULON_EG_異常履歷]",
        //                    "*",
        //                    "",
        //                    "");
        //    return General.Query(connAp01_54, cmd);
        //}

        public static List<dynamic> QueryAsTestLine(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[YULON_AS_TestinLine] ",
                            "*",
                            $"[CREATE_TIME] >= '{sb}' AND [CREATE_TIME] <= '{se}'",
                            "[CREATE_TIME]");

            return General.Query(connAp01_54, cmd);
        }
    }
}
