﻿using System;
using System.Collections.Generic;
using System.Data;

namespace SqlFrameworkLibrary.CRUD
{
    public class OeeBe
    {
        public static string connAp01_54 = Utility.Basic.connAp01_54;
        public static string connAp03 = Utility.Basic.connAp03;
        public static string connBeAlc = Utility.Basic.connBeAlc;

        /// <summary>
        /// 儲能線設備資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryBATTERY_SIGNAL(DateTime dtb, DateTime dte, string line)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("BATTERY_SIGNAL",
                            "[dttm]'RQ',[update_dttm],[line_id],[type],isnull([op1],0)[op1],isnull([op2],0)[op2],isnull([op3],0)[op3],isnull([op4],0)[op4],isnull([op5],0)[op5],isnull([op6],0)[op6],isnull([op7],0)[op7],isnull([op8],0)[op8],isnull([op9],0)[op9],isnull([op10],0)[op10],isnull([op11],0)[op11],isnull([op12],0)[op12],isnull([op13],0)[op13],isnull([op14],0)[op14],isnull([op15],0)[op15],isnull([op16],0)[op16],isnull([op17],0)[op17],isnull([op18],0)[op18],isnull([op19],0)[op19],isnull([op20],0)[op20],[is_alive]",
                            $"[dttm] >= '{sb}' AND [dttm] < '{se}' AND [type] in ('run','err','emg') AND [line_id] IN ('{line}')",
                            "[dttm]");
            return General.Query(connAp03, cmd);
        }
        /// <summary>
        /// 新儲能線設備資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryNewBATTERY_SIGNAL(DateTime dtb, DateTime dte, string line)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");
            
            string cmd = line.Equals("D','E,'L") ?
                $"EXEC [APDB03].[dbo].[APDB03_GetSIGNAL]'{sb}','{se}'"
                :
                "SELECT [dttm]'RQ',[tag_line_id],[tag_name_chn]'type',CAST(isnull([1],0) AS BIT)'op1',CAST(isnull([2],0) AS BIT)'op2',CAST(isnull([3],0) AS BIT)'op3',CAST(isnull([4],0) AS BIT)'op4',CAST(isnull([5],0) AS BIT)'op5',CAST(isnull([6],0) AS BIT)'op6',CAST(isnull([7],0) AS BIT)'op7',CAST(isnull([8],0) AS BIT)'op8',CAST(isnull([9],0) AS BIT)'op9',CAST(isnull([10],0) AS BIT)'op10',CAST(isnull([11],0) AS BIT)'op11',CAST(isnull([12],0) AS BIT)'op12',CAST(isnull([13],0) AS BIT)'op13',CAST(isnull([14],0) AS BIT)'op14' FROM (SELECT[dttm],CAST([tag_value] AS TINYINT)[tag_value],b.[tag_line_id],b.[tag_operation_num],b.[tag_name_chn]  FROM[APDB03].[dbo].[PLC_RECEIVER_BIT] A, [APDB03].[dbo].[PLC_TAG] B where a.tag_num = b.tag_num " +
                $"AND A.dttm BETWEEN '{sb}' AND '{se}' AND b.[tag_line_id] IN ('{line}') " +
                "AND b.[tag_name_chn] IN('運轉', '緊急停止', '故障','禁止投入') ) D  PIVOT(MAX(tag_value) FOR tag_operation_num IN([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12],[13],[14]) ) P ORDER BY dttm";
            
            return General.Query(connAp03, cmd);
        }



        /// <summary>
        /// 儲能線ALC資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryTB_ES_V(DateTime dtb, DateTime dte, string Name, string Dttm1, string Dttm2, string Num)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");
            string cmd = "";
            if (Name.Equals("Test")) 
            {
                cmd = "SELECT 'SRI_DTTM'[LINE],[TYPE_ID],[SRO_DTTM][TIME]  FROM [YLALC_ES].[dbo].[TB_ES_V] " +
                    $"WHERE [SRI_DTTM] >= '{sb}' AND [SRI_DTTM] < '{se}'  AND left(PRD_SN,2) IN ('30','40')" +
                    "UNION ALL SELECT 'JP_DTTM'[LINE],[TYPE_ID],[JP_DTTM][TIME]  FROM [YLALC_ES].[dbo].[TB_ES_V] " +
                    $"WHERE [JP_DTTM] >= '{sb}' AND [JP_DTTM] < '{se}'  AND left(PRD_SN,2) IN ('50')";
            }
            else
            {
                cmd = $"SELECT '{Dttm1}'[LINE],[TYPE_ID],[{Dttm1}][TIME]  FROM [YLALC_ES].[dbo].[TB_ES_V] " +
                    $"WHERE [{Dttm1}] >= '{sb}' AND [{Dttm1}] < '{se}' AND left(PRD_SN,2) IN ('{Num}')" +
                    $"UNION ALL SELECT '{Dttm2}'[LINE],[TYPE_ID],[{Dttm2}][TIME]  FROM [YLALC_ES].[dbo].[TB_ES_V] " +
                    $"WHERE [{Dttm2}] >= '{sb}' AND [{Dttm2}] < '{se}' AND left(PRD_SN,2) IN ('{Num}')";
            }
            return General.Query(connBeAlc, cmd);
        }
        /// <summary>
        /// 儲能線ALC資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryTB_ES_V_Pass(DateTime dtb, DateTime dte,int Line)
        {
            string Key1 = "";
            string Key2 = "";
            switch (Line) 
            {
                case 0:
                    Key1 = "MDO_DTTM";
                    Key2 = "'1A','1B'";
                    break;
                case 1:
                    Key1 = "PAO_DTTM";
                    Key2 = "'2A','2B'";
                    break;
                case 2:
                    Key1 = "SRO_DTTM";
                    Key2 = "'30','40'";
                    break;
                case 3:
                    Key1 = "STO_DTTM";
                    Key2 = "'50'";
                    break;
            }            
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");
            string cmd = $"SELECT [{Key1}]  FROM [YLALC_ES].[dbo].[TB_ES_V] where left(PRD_SN,2) IN ({Key2}) " +
                $"AND[{Key1}] BETWEEN '{sb}' AND '{se}' ORDER BY[{Key1}]";
            return General.Query(connBeAlc, cmd);
        }

        /// <summary>
        /// 儲能線IQM Q類損失資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryDAY_RECORD(DateTime dtb, DateTime dte, string Line)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = "SELECT CAST ( [RQ] AS NVARCHAR) + ' '[RQ],[open_time_predict],[open_time_real],[close_time_predict],[close_time_real],[oee_p1] FROM [APDB01].[dbo].[YULON_AS_DAY_RECORD] " +
                $"where RQ >= '{sb}' and RQ < '{se}' and Line = '{Line}' and section <> 24";
            ;
            return General.Query(connAp01_54, cmd);
        }

        /// <summary>
        /// 儲能線IQM Q類損失資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QueryIQM(DateTime dtb, DateTime dte, string sn)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = //"SELECT [DATE],[DEFECT_DESC],[OPERATION],[SN] FROM (SELECT ROW_NUMBER()OVER(PARTITION BY SN order by[INSP_TIME])Num,[INSP_TIME][DATE],[DEFECT_DESC],[OPERATION],[SN] FROM [APDB03].[dbo].[IQM_YL_OEE_ENERGY_DEFECT_V] " +
            //$"where left(sn,2) in ('{sn}') and [INSP_TIME] > '{sb}' and [INSP_TIME] < '{se}') D WHERE D.Num = 1 ";
            "SELECT [INSP_TIME][DATE],[DEFECT_DESC],[OPERATION],[SN] FROM [APDB03].[dbo].[IQM_YL_OEE_ENERGY_DEFECT_V] " +
            $"where left(sn,2) in ('{sn}') and [INSP_TIME] > '{sb}' and [INSP_TIME] < '{se}' ";
            //+
            //"UNION ALL SELECT [DATE],[DEFECT_DESC],[OPERATION],SN FROM( SELECT UPLOAD_TIME[DATE],sn,MAX(BATCH_SIZE)BATCH_SIZE, COUNT(SEQ)SEQ,case when MAX(BATCH_SIZE) > COUNT(SEQ) then '結構不良' else '' end [DEFECT_DESC],[EQP_NO]+[EQP_NAME][OPERATION] FROM [APDB03].[dbo].[IQM_YL_OEE_ENERGY_TORQUE_V] " +
            //$"where UPLOAD_TIME >= '{sb}' and UPLOAD_TIME < '{se}' " +
            //$"group by sn, UPLOAD_TIME,[EQP_NO]+[EQP_NAME] ) D WHERE D.DEFECT_DESC != ''";
            ;
            return General.Query(connAp03, cmd);
        }

        /// <summary>
        /// 儲能線A類工單
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<SqlFrameworkLibrary.Model.OeeAs.OeeAsErrorHistory> CRE_YULON_BE_ERROR(DateTime dtb, DateTime dte)
        {
            string sb = dtb.AddHours(8).ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.AddHours(16).AddMinutes(45).ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = $"select * FROM [APDB03].[dbo].[CRE_YULON_BE_ERROR]('{sb}','{se}')";
            return General.Query<SqlFrameworkLibrary.Model.OeeAs.OeeAsErrorHistory>(connAp03, cmd);
        }
        /// <summary>
        /// 儲能線IQM P類損失資料
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <returns></returns>
        public static List<dynamic> QuerySIGNAL_COUNT(DateTime dtb, DateTime dte, int num,double TT)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = "select START_TIME,END_TIME,DIFF FROM ( " +
                "select MIN(dttm)START_TIME,MAX(dttm)END_TIME,DATEDIFF(MINUTE, MIN(dttm), MAX(dttm))DIFF,tag_value from[APDB03].[dbo].[PLC_RECEIVER_VALUE] " +
                $"where dttm BETWEEN '{sb}' AND '{se}' AND tag_num = {num}  group by tag_value ) D WHERE DIFF > {TT} ORDER BY tag_value ";
            ;
            return General.Query(connAp03, cmd);
        }

        /// <summary>
        /// 歷史生產台數
        /// </summary>
        /// <param name="dtb"></param>
        /// <param name="dte"></param>
        /// <param name="factory"></param>
        /// <param name="zone"></param>
        /// <param name="line"></param>
        /// <returns></returns>
        public static List<dynamic> QueryPcsMon(DateTime dtb, DateTime dte, string factory, string zone,string line)
        {
            string sb = dtb.AddDays(1- dtb.Day).ToString("yyyy/MM/dd");
            string se = dte.ToString("yyyy/MM/dd");
            string se2 = dte.AddDays(1).ToString("yyyy/MM/dd");

            string cmd = "SELECT * FROM ( SELECT [line],sum([pcs_day_predict])[pcs_mon_predict],sum([pcs_day_target])[pcs_mon_target],sum([pcs_day_real])[pcs_mon_real],sum([kwh_day_predict])[kwh_mon_predict],sum([kwh_day_real])[kwh_mon_real] FROM [APDB01].[dbo].[YULON_AS_DAY_RECORD] " +
                $"where [factory] = '{factory}' and [zone] = '{zone}' and [line] = '{line}' and [section] = 24 and [is_work_day] = 1 and [RQ] >= '{sb}' and [RQ] < '{se}' group by [line] ) D " +
                $"left join (SELECT line,close_time_predict from [APDB01].[dbo].[YULON_AS_DAY_RECORD] where [factory] = '{factory}' and [zone] = '{zone}' and [line] = '{line}' and [section] = 24 and [is_work_day] = 1 and [RQ] >= '{se}' and [RQ] < '{se2}' ) c on D.line = c.line ";
            ;
            return General.Query(connAp01_54, cmd);
        }

        public static List<dynamic> QueryMAXTIME_ERROR_HISTORY(string fac,string zon)
        {
            string cmd = $"SELECT MAX(RQ)RQ FROM [APDB01].[dbo].[YULON_AS_ERROR_HISTORY] where [factory] = '{fac}' and [zone] = '{zon}'";
            return General.Query(connAp01_54, cmd);
        }


        public static List<dynamic> QueryAp01(string cmd) 
        {
            return General.Query(connAp01_54, cmd);
        }       

        public static DataTable GetOeeDAY_RECORD_BE(string Factory, string RQB, string RQE, string Line, List<Model.OeeAs.OEE_SHOW_TITLE> HEADER)
        {
            string strQuery = $"exec GetOeeDAY_RECORD_BE '{Factory}','{RQB}','{RQE}','{Line}','{HEADER[0].oee_a1}','{HEADER[0].oee_a2}','{HEADER[0].oee_a3}','{HEADER[0].oee_a4}','{HEADER[0].oee_a5}','{HEADER[0].oee_a6}','{HEADER[0].oee_a7}','{HEADER[0].oee_a8}','{HEADER[0].oee_a9}','{HEADER[0].oee_p1}','{HEADER[0].oee_p2}','{HEADER[0].oee_p3}','{HEADER[0].oee_p4}','{HEADER[0].oee_p5}','{HEADER[0].oee_p6}','{HEADER[0].oee_p7}','{HEADER[0].oee_p8}','{HEADER[0].oee_p9}','{HEADER[0].oee_q1}','{HEADER[0].oee_q2}','{HEADER[0].oee_q3}','{HEADER[0].oee_q4}','{HEADER[0].oee_q5}','{HEADER[0].oee_q6}','{HEADER[0].oee_q7}','{HEADER[0].oee_q8}','{HEADER[0].oee_q9}'";
            return General.DataTableQuery(connAp01_54, strQuery);
        }
        public static DataTable GetOeeDAY_RECORD_AS(string Factory, string RQB, string RQE, string Line, List<Model.OeeAs.OEE_SHOW_TITLE> HEADER)
        {
            string strQuery = $"exec GetOeeDAY_RECORD_AS '{Factory}','{RQB}','{RQE}','{Line}','{HEADER[0].oee_a1}','{HEADER[0].oee_a2}','{HEADER[0].oee_a3}','{HEADER[0].oee_a4}','{HEADER[0].oee_a5}','{HEADER[0].oee_a6}','{HEADER[0].oee_a7}','{HEADER[0].oee_a8}','{HEADER[0].oee_a9}','{HEADER[0].oee_p1}','{HEADER[0].oee_p2}','{HEADER[0].oee_p3}','{HEADER[0].oee_p4}','{HEADER[0].oee_p5}','{HEADER[0].oee_p6}','{HEADER[0].oee_p7}','{HEADER[0].oee_p8}','{HEADER[0].oee_p9}','{HEADER[0].oee_q1}','{HEADER[0].oee_q2}','{HEADER[0].oee_q3}','{HEADER[0].oee_q4}','{HEADER[0].oee_q5}','{HEADER[0].oee_q6}','{HEADER[0].oee_q7}','{HEADER[0].oee_q8}','{HEADER[0].oee_q9}'";
            return General.DataTableQuery(connAp01_54, strQuery);
        }
        public static DataTable GetOeeDAY_RECORD(string Factory, string RQB, string RQE, string Line, List<Model.OeeAs.OEE_SHOW_TITLE> HEADER)
        {
            string strQuery = $"exec GetOeeDAY_RECORD '{Factory}','{RQB}','{RQE}','{Line}','{HEADER[0].oee_a1}','{HEADER[0].oee_a2}','{HEADER[0].oee_a3}','{HEADER[0].oee_a4}','{HEADER[0].oee_a5}','{HEADER[0].oee_a6}','{HEADER[0].oee_a7}','{HEADER[0].oee_a8}','{HEADER[0].oee_a9}','{HEADER[0].oee_p1}','{HEADER[0].oee_p2}','{HEADER[0].oee_p3}','{HEADER[0].oee_p4}','{HEADER[0].oee_p5}','{HEADER[0].oee_p6}','{HEADER[0].oee_p7}','{HEADER[0].oee_p8}','{HEADER[0].oee_p9}','{HEADER[0].oee_q1}','{HEADER[0].oee_q2}','{HEADER[0].oee_q3}','{HEADER[0].oee_q4}','{HEADER[0].oee_q5}','{HEADER[0].oee_q6}','{HEADER[0].oee_q7}','{HEADER[0].oee_q8}','{HEADER[0].oee_q9}'";
            return General.DataTableQuery(connAp01_54, strQuery);
        }
    }
}
