﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.CRUD
{
    public class FuncCheck
    {
        private static string connFunCheck = Utility.Basic.connFunCheck;

        public static List<dynamic> QueryUpload(DateTime dtb, DateTime dte)
        {
            string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
            string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

            string cmd = General.BasicCmd("[UPLOAD]",
                            "*",
                            $"[UPLOAD_DATE_TIME] >= '{sb}' and [UPLOAD_DATE_TIME] < '{se}'",
                            "[UPLOAD_DATE_TIME]");

            return General.Query(connFunCheck, cmd);
        }

        public static List<dynamic> QueryFailList(string fileName)
        {
            string cmd = General.BasicCmd("[FAIL_LIST]",
                            "*",
                            $"[FILE_NAME] = '{fileName}'",
                            "");

            return General.Query(connFunCheck, cmd);
        }
    }
}
