﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//load ini
using System.Runtime.InteropServices;

namespace SqlFrameworkLibrary.Utility
{

    public class Basic
    {
        //static public string conn = GetConnectionString();
        //For test 2022/3/15
        static public string connAp01_Test = GetConnectionString("APDB01", "dbap01", "dbap01@ADMIN");
        //
        //2022 03 24 車廠
        static public string connModBus = GetConnectionString("Product_Assembly_Warning_Info", "sa", "123456", "10.202.72.1");

        //static public string connAp01 = GetConnectionString("APDB01", "dbap01", "dbap01@ADMIN", "10.202.2.54"); // 取代GetConnectionString("APDB01", "dbap01", "dbap01@ADMIN");
        //static public string connAp01_54 = GetConnectionString("APDB01", "dbap01", "dbap01@ADMIN", "10.202.2.54");
        //static public string connAp02 = GetConnectionString("APDB02", "dbap02", "dbap02pwd", "10.202.2.54");
        //static public string connAp03 = GetConnectionString("APDB03", "btap01", "btap01pwd", "10.202.2.54");

        static public string connAp01 = GetConnectionString("APDB01"); // 取代GetConnectionString("APDB01", "dbap01", "dbap01@ADMIN");
        static public string connAp01_54 = GetConnectionString("APDB01");
        static public string connAp02 = GetConnectionString("APDB02");
        static public string connAp03 = GetConnectionString("APDB03");

        static public string connAlcSa = GetConnectionString("YLALC", "alcssa", "alcssa", "ylalcs01");
        static public string connAlc = GetConnectionString("YLALC", "OEEAP01", "OEEAP01@pwd", "ylalcs01");
        static public string connSpc = GetConnectionString("YLEPMDB", "oeeap01", "oeeap01@pwd", "10.202.2.87"); // ylspcs02
        static public string connFunCheck = GetConnectionString("FUNCHECK", "cylee", "1234", @"10.202.73.32\sqlexpress");
        static public string connEngineBC = GetConnectionString("BC_DataRecord" , "e9751", "9751", "Engine_Line_PC2");
        static public string connBeAlc = GetConnectionString("YLALC_ES", "esoeeap01", "oeeap01pwd", "ylncps02");
        //static public string connPaintAPP = GetConnectionString("ylpeps02", "PaintAP01", "oeeap01pwd", "ylncps02");
        static public string connIqm = "";
        //
        public  void doTest()
        {
            //抓目前是測試還是正式
            IniManager iniManager = new IniManager("D:/YLCC.ini");
            string ip = iniManager.ReadIniFile("APDB01", "IP");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="db"></param>
        /// <param name="account"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        static public string GetConnectionString(string db = "APDB01", string account = "dbap01", string password = "dbap01@ADMIN", string ip = "10.202.2.100,5001")
        {
           

            //抓目前是測試還是正式
            //IniManager iniManager = new IniManager("D:/YLCC.ini");
            ////string LKTpe = iniManager.ReadIniFile("LINK_TYPE", "TYPE");
            ////if(LKTpe == "測試")   db  += LKTpe;
            ////Load Ini
            //ip = iniManager.ReadIniFile(db , "IP");
            //db = iniManager.ReadIniFile(db, "DB");
            //account = iniManager.ReadIniFile(db, "ACCOUNT");
            //password = iniManager.ReadIniFile(db, "PASSWORD");

            // To avoid storing the connection string in your code,
            // you can retrieve it from a configuration file.
            return $"Data Source={ip}; " +//"Data Source=10.202.2.100,5001; " +
                $"Initial Catalog={db};" +
                "Integrated Security=False;" +
                $"User ID={account};" +
                $"Password={password}; " +
                "Connect Timeout=15;" +
                "Encrypt=False;" +
                "TrustServerCertificate=True;" +
                "ApplicationIntent=ReadWrite;" +
                "MultiSubnetFailover=False;" +
                "multipleactiveresultsets=true;";
        }

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="db"></param>
        ///// <param name="account"></param>
        ///// <param name="password"></param>
        ///// <returns></returns>
        //static public string GetConnectionAp01String(string db = "APDB01", string account = "dbap01", string password = "dbap01@ADMIN")
        //{
        //    // To avoid storing the connection string in your code,
        //    // you can retrieve it from a configuration file.
        //    return "Data Source=10.202.2.100,5001; " +
        //        $"Initial Catalog={db}; " +
        //        "Integrated Security=False;" +
        //        $"User ID={account};" +
        //        $"Password={password}; " +
        //        "Connect Timeout=15;" +
        //        "Encrypt=False;" +
        //        "TrustServerCertificate=True;" +
        //        "ApplicationIntent=ReadWrite;" +
        //        "MultiSubnetFailover=False;" +
        //        "multipleactiveresultsets=true;";
        //}

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="db"></param>
        ///// <param name="account"></param>
        ///// <param name="password"></param>
        ///// <returns></returns>
        //static public string GetConnectionAp02String(string db = "APDB02", string account = "dbap02", string password = "dbap02pwd")
        //{
        //    // To avoid storing the connection string in your code,
        //    // you can retrieve it from a configuration file.
        //    return "Data Source=10.202.2.100,5001; " +
        //        $"Initial Catalog={db};" +
        //        "Integrated Security=False;" +
        //        $"User ID={account};" +
        //        $"Password={password}; " +
        //        "Connect Timeout=15;" +
        //        "Encrypt=False;" +
        //        "TrustServerCertificate=True;" +
        //        "ApplicationIntent=ReadWrite;" +
        //        "MultiSubnetFailover=False;" +
        //        "multipleactiveresultsets=true;";
        //}


        //static public string GetConnectionSpcString(string db = "YLEPMDB", string account = "oeeap01", string password = "oeeap01@pwd")
        //{
        //    // To avoid storing the connection string in your code,
        //    // you can retrieve it from a configuration file.
        //    return "Data Source=10.202.2.87; " +
        //        $"Initial Catalog={db};" +
        //        "Integrated Security=False;" +
        //        $"User ID={account};" +
        //        $"Password={password}; " +
        //        "Connect Timeout=15;" +
        //        "Encrypt=False;" +
        //        "TrustServerCertificate=True;" +
        //        "ApplicationIntent=ReadWrite;" +
        //        "MultiSubnetFailover=False;" +
        //        "multipleactiveresultsets=true;";
        //}

        //static public string GetConnectionAlcString(string db = "YLALC", string account = "OEEAP01", string password = "OEEAP01@pwd")
        //{
        //    // To avoid storing the connection string in your code,
        //    // you can retrieve it from a configuration file.
        //    return "Data Source=ylalcs01; " +
        //        $"Initial Catalog={db};" +
        //        "Integrated Security=False;" +
        //        $"User ID={account};" +
        //        $"Password={password}; " +
        //        "Connect Timeout=15;" +
        //        "Encrypt=False;" +
        //        "TrustServerCertificate=True;" +
        //        "ApplicationIntent=ReadWrite;" +
        //        "MultiSubnetFailover=False;" +
        //        "multipleactiveresultsets=true;";
        //}
    }
    #region Load ini Function
    public class IniManager
    {
        private string filePath;
        private StringBuilder lpReturnedString;
        private int bufferSize;

        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string lpString, string lpFileName);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string lpDefault, StringBuilder lpReturnedString, int nSize, string lpFileName);

        public IniManager(string iniPath)
        {
            filePath = iniPath;
            bufferSize = 512;
            lpReturnedString = new StringBuilder(bufferSize);
        }

        // read ini date depend on section and key
        public string ReadIniFile(string section, string key, string defaultValue = "尋找不到該值")
        {
            lpReturnedString.Clear();
            GetPrivateProfileString(section, key, defaultValue, lpReturnedString, bufferSize, filePath);
            return lpReturnedString.ToString();
        }

        // write ini data depend on section and key
        public void WriteIniFile(string section, string key, Object value)
        {
            WritePrivateProfileString(section, key, value.ToString(), filePath);
        }
    }
    #endregion
}
