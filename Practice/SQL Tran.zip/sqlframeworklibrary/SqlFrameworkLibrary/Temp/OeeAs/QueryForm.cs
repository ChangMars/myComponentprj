﻿using SqlFrameworkLibrary.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.OeeAs
{
    public class QueryForm
    {
    //    private static string connAp01 = Utility.Basic.connAp01;
    //    private static string connAp02 = Utility.Basic.connAp02;

    //    public static List<dynamic> QueryAsKwhReal(DateTime dtb, DateTime dte)
    //    {
    //        string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
    //        string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

    //        string cmd = General.BasicCmd("[YULON_AS_NYKB] ",
    //                        "[RQ],[SJ] ,[車裝工場_累計1_0_0_0] AS gcb, " +
    //                        "[組裝線_累計1_1_0_0] AS acb1, [P11升降機_累計1_1_1_1] AS acb2 ," +
    //                        "[P1升降機_累計1_1_1_2] AS acb3 ,[高空輸送鏈條_累計1_1_1_3] AS acb4 ," +
    //                        "[輪胎線_累計1_1_2_0] AS acb5 , [新底盤系統_累計1_1_3_0] AS acb6 ," +
    //                        "[a_累計] AS else1 , [b_累計] AS else2 ," +
    //                        "[c_累計] AS else3 , [d_累計] AS else4",
    //                        $"[RQ] >= '{sb}' AND [RQ] < '{se}'",
    //                        "[RQ] asc");

    //        return General.Query(connAp01, cmd);
    //    }

    //    public static List<dynamic> QueryAsModbus(DateTime dtb, DateTime dte)
    //    {
    //        string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
    //        string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

    //        string cmd = General.BasicCmd("YULON_AS_Modbus",
    //                        "*",
    //                        $"[RQ] >= '{sb}' AND [RQ] < '{se}'",
    //                        "[RQ]");
    //        return General.Query(connAp01, cmd);
    //    }

    //    public static List<dynamic> QueryAsDayRecord(DateTime dtb, DateTime dte)
    //    {
    //        string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
    //        string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

    //        string cmd = General.BasicCmd("YULON_AS_DAY_RECORD",
    //                        "*",
    //                        $"[RQ] >= '{sb}' AND [RQ] < '{se}'",
    //                        "[RQ]");
    //        return General.Query(connAp01, cmd);
    //    }

    //    public static List<YULON_AS_DAY_RECORD> QueryAsDayRecord<YULON_AS_DAY_RECORD>(DateTime dtb, DateTime dte)
    //    {
    //        string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
    //        string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

    //        string cmd = General.BasicCmd("YULON_AS_DAY_RECORD",
    //                        "*",
    //                        $"[RQ] >= '{sb}' AND [RQ] < '{se}'",
    //                        "[RQ]");
    //        return General.Query<YULON_AS_DAY_RECORD>(connAp01, cmd);
    //    }

    //    public static List<YULON_AS_DAY_RECORD> QueryAsDayRecord<YULON_AS_DAY_RECORD>(DateTime dtb, DateTime dte, string factory, string zone)
    //    {
    //        string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
    //        string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

    //        string cmd = General.BasicCmd("YULON_AS_DAY_RECORD",
    //                        "*",
    //                        $"[RQ] >= '{sb}' AND [RQ] < '{se}' AND [factory] = '{factory}' AND [zone] = '{zone}'",
    //                        "[RQ]");
    //        return General.Query<YULON_AS_DAY_RECORD>(connAp01, cmd);
    //    }

    //    /// <summary>
    //    /// Query CCR Predict Car Line
    //    /// </summary>
    //    /// <param name="dtb"></param>
    //    /// <param name="dte"></param>
    //    /// <returns></returns>
    //    public static List<AsCcrPrdt> QueryCcrPrdt(DateTime dtb, DateTime dte)
    //    {
    //        string sb = dtb.ToString("yyyy/MM/dd 00:00:00");
    //        string se = dte.ToString("yyyy/MM/dd 23:59:59");

    //        string cmd = General.BasicCmd("YULON_AS_CCR_PRDT ",
    //                        "DISTINCT [modl] + [chs_no] AS [modl_chs_no], [car_qty], [modl], [ccr_prdt_dttm] ",
    //                        $"[RQ] >= '{sb}' AND [RQ] < '{se}'",
    //                        "[car_qty] asc");

    //        // 為了排序特別處理
    //        var ccrPrdtDst = General.Query<AsCcrPrdt>(connAp01, cmd);
    //        var qtyNull = ccrPrdtDst.FindAll(x => x.car_qty is null);
    //        var qtyNum = ccrPrdtDst.FindAll(x => x.car_qty != null);
    //        qtyNum.AddRange(qtyNull);

    //        return qtyNum;
    //    }

    //    /// <summary>
    //    /// Query ALC Actural Car Line
    //    /// </summary>
    //    /// <param name="dtb"></param>
    //    /// <param name="dte"></param>
    //    /// <returns></returns>
    //    public static List<dynamic> QueryAsAlc(DateTime dtb, DateTime dte)
    //    {
    //        string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
    //        string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

    //        string cmd = General.BasicCmd("YULON_AS_ALC",
    //                        "*",
    //                        $"[ti_dttm] >= '{sb}' AND [ti_dttm] < '{se}'",
    //                        "[ti_dttm]");
    //        return General.Query(connAp01, cmd);
    //    }

    //    public static List<dynamic> QueryAsAlcCalendar(DateTime dtb, DateTime dte)
    //    {
    //        string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
    //        string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

    //        string cmd = General.BasicCmd("YULON_AS_CALENDAR",
    //                        "*",
    //                        $"[begn_dttm] >= '{sb}' AND [begn_dttm] < '{se}'",
    //                        "[begn_dttm]");
    //        return General.Query(connAp01, cmd);
    //    }

    //    public static List<AsCarModl> QueryCarModl(string year)
    //    {
    //        string cmd = General.BasicCmd("YULON_AS_CAR_MODL",
    //                        "*",
    //                        $"[is_invalid] <> 1 AND [year] = '{year}'",
    //                        "sn");
    //        return General.Query<AsCarModl>(connAp01, cmd);
    //    }

    //    public static List<AsCarProductivity> QueryAsCarProductivity(string year, string factory, string zone)
    //    {
    //        string cmd = General.BasicCmd("YULON_AS_CAR_PRODUCTIVITY",
    //                "*",
    //               $"[is_invalid] <> 1 AND [year] = '{year}' AND [factory] = '{factory}' AND [zone] = '{zone}'",
    //                "");
    //        return General.Query<AsCarProductivity>(connAp01, cmd);
    //    }

    //    public static List<dynamic> QueryAsDevKwhPara(string factory, string zone)
    //    {
    //        string cmd = General.BasicCmd("[YULON_AS_DEV_KWH_PARA] ",
    //                        "*",
    //                        $"[factory] = '{factory}' AND [zone] = '{zone}'",
    //                        "");

    //        return General.Query(connAp01, cmd);
    //    }

    //    //public static List<AsDevKwhPara> QueryAsDevKwhPara(string factory, string zone)
    //    //{
    //    //    string cmd = General.BasicCmd("[YULON_AS_DEV_KWH_PARA] ",
    //    //                    "*",
    //    //                    $"[is_invalid] <> 1 AND [factory] = '{factory}' AND [zone] = '{zone}'",
    //    //                    "");

    //    //    return General.Query<AsDevKwhPara>(connAp01, cmd);
    //    //}

    //    // ----------------------------------------------------------------------------------------
    //    public static List<dynamic> QueryTestLine(DateTime dtb, DateTime dte)
    //    {
    //        return QueryTestLine(dtb, dte, "");
    //    }
    //    public static List<dynamic> QueryTestLine(DateTime dtb, DateTime dte, string addCondition)
    //    {
    //        string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
    //        string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

    //        string whereCondition = $"[CREATE_TIME] >= '{sb}' AND [CREATE_TIME] < '{se}'";
    //        if (!string.IsNullOrEmpty(addCondition))
    //        {
    //            whereCondition += " " + addCondition;
    //        }

    //        string cmd = General.BasicCmd("YULON_AS_TestinLine",
    //                        "*",
    //                        whereCondition,
    //                        "[CREATE_TIME]");
    //        return General.Query(connAp01, cmd);
    //    }
    //    // ----------------------------------------------------------------------------------------
    //    public static List<dynamic> QueryRfNext(DateTime dtb, DateTime dte)
    //    {
    //        return QueryRfNext(dtb, dte, "");
    //    }
    //    public static List<dynamic> QueryRfNext(DateTime dtb, DateTime dte, string addCondition)
    //    {
    //        string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
    //        string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

    //        string whereCondition = $"[UPDATE_TIME] >= '{sb}' AND [UPDATE_TIME] < '{se}'";
    //        if (!string.IsNullOrEmpty(addCondition))
    //        {
    //            whereCondition += " " + addCondition;
    //        }

    //        string cmd = General.BasicCmd("YULON_AS_RFNext",
    //                        "*",
    //                        whereCondition,
    //                        "[UPDATE_TIME]");
    //        return General.Query(connAp01, cmd);
    //    }
    //    // ----------------------------------------------------------------------------------------
    //    public static List<dynamic> QueryAsIqm(DateTime dtb, DateTime dte)
    //    {
    //        return QueryAsIqm(dtb, dte, "");
    //    }
    //    public static List<dynamic> QueryAsIqm(DateTime dtb, DateTime dte, string addCondition)
    //    {
    //        string sb = dtb.ToString("yyyy/MM/dd HH:mm:ss");
    //        string se = dte.ToString("yyyy/MM/dd HH:mm:ss");

    //        string whereCondition = $"[insp_time] >= '{sb}' AND [insp_time] < '{se}'";
    //        if (!string.IsNullOrEmpty(addCondition))
    //        {
    //            whereCondition += " " + addCondition;
    //        }
    //        string cmd = General.BasicCmd("IQM_YL_OEE_LOT_INSP_HIS",
    //                        "*",
    //                        whereCondition,
    //                        "[insp_time]");
    //        // 針對缺下
    //        // DEFECT_DESC LIKE '%申告待補%' OR DEFECT_DESC LIKE '%缺料%' OR DEFECT_DESC LIKE '%欠品% 
    //        return General.Query(connAp02, cmd);
    //    }
    }
}
