﻿using SqlFrameworkLibrary.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.OeeAs
{
    public class ExcuteForm
    {
        //private static string connAp01 = Utility.Basic.connAp01;
        //private static string connAp02 = Utility.Basic.connAp02;

        //public static void InvalidCarModl(List<AsCarModl> results, string year)
        //{
        //    // string year = dt.ToString("yyyy");
        //    string cmd = "UPDATE YULON_AS_CAR_MODL " +
        //        "SET [is_invalid] = @is_invalid, [invalid_time] = @invalid_time " +
        //        $"WHERE [is_invalid] <> 1 AND [year] = {year}";

        //    General.Excute<AsCarModl>(connAp01, cmd, results);
        //}

        //public static void InvalidCarProductivity(List<AsCarProductivity> results, string year)
        //{
        //    // string year = dt.ToString("yyyy");
        //    string cmd = "UPDATE YULON_AS_CAR_PRODUCTIVITY " +
        //        "SET [is_invalid] = @is_invalid, [invalid_time] = @invalid_time " +
        //        $"WHERE [is_invalid] <> 1 AND [year] = {year}";

        //    General.Excute<AsCarProductivity>(connAp01, cmd, results);
        //}

        //public static void InsertCarModl(List<AsCarModl> results)
        //{
        //    string cmd = "INSERT INTO YULON_AS_CAR_MODL(" +
        //        "[year]" +
        //        ",[big_or_small]" +
        //        ",[modl]" +
        //        ",[dst]" +
        //        ",[equivalent_units]" +
        //        ",[build_time]" +
        //        ",[is_invalid]" +
        //        ",[invalid_time] " +
        //        ") VALUES (" +
        //        "@year" +
        //        ",@big_or_small" +
        //        ",@modl" +
        //        ",@dst" +
        //        ",@equivalent_units" +
        //        ",@build_time" +
        //        ",@is_invalid" +
        //        ",@invalid_time " +
        //        "); ";

        //    General.Excute<AsCarModl>(connAp01, cmd, results);
        //}

        //public static void InsertCarProductivity(AsCarProductivity results)
        //{
        //    string cmd = "INSERT INTO YULON_AS_CAR_PRODUCTIVITY(" +
        //        "[year]" +
        //        ",[jan]" +
        //        ",[feb]" +
        //        ",[mar]" +
        //        ",[apr]" +
        //        ",[may]" +
        //        ",[jun]" +
        //        ",[jul]" +
        //        ",[aug]" +
        //        ",[sep]" +
        //        ",[oct]" +
        //        ",[nov]" +
        //        ",[dec]" +
        //        ",[jan_base]" +
        //        ",[feb_base]" +
        //        ",[mar_base]" +
        //        ",[apr_base]" +
        //        ",[may_base]" +
        //        ",[jun_base]" +
        //        ",[jul_base]" +
        //        ",[aug_base]" +
        //        ",[sep_base]" +
        //        ",[oct_base]" +
        //        ",[nov_base]" +
        //        ",[dec_base]" +
        //        ",[mix_big_equvalent_units]" +
        //        ",[mix_small_equvalent_units]" +
        //        ",[build_time]" +
        //        ",[is_invalid]" +
        //        ",[invalid_time]" +
        //        ") VALUES (" +
        //        "@year" +
        //        ",@jan" +
        //        ",@feb" +
        //        ",@mar" +
        //        ",@apr" +
        //        ",@may" +
        //        ",@jun" +
        //        ",@jul" +
        //        ",@aug" +
        //        ",@sep" +
        //        ",@oct" +
        //        ",@nov" +
        //        ",@dec" +
        //        ",@jan_base" +
        //        ",@feb_base" +
        //        ",@mar_base" +
        //        ",@apr_base" +
        //        ",@may_base" +
        //        ",@jun_base" +
        //        ",@jul_base" +
        //        ",@aug_base" +
        //        ",@sep_base" +
        //        ",@oct_base" +
        //        ",@nov_base" +
        //        ",@dec_base" +
        //        ",@mix_big_equvalent_units" +
        //        ",@mix_small_equvalent_units" +
        //        ",@build_time" +
        //        ",@is_invalid" +
        //        ",@invalid_time" +
        //        "); ";

        //    General.Excute<AsCarProductivity>(connAp01, cmd, results);
        //}
    }
}
