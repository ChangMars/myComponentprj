﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.Model
{
    public class Alc
    {
        public class AlcEmdlSpcPara
        {
            public string equip_no { get; set; }
            public string emdl { get; set; }
            public string car_serail { get; set; }
            public int upload_count { get; set; }
            public DateTime update_dttm { get; set; }
            public string update_user { get; set; }
        }
    }
}
