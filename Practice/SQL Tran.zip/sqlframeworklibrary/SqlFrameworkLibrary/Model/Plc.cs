﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.Model
{
    public class Plc
    {
        [Dapper.Contrib.Extensions.Table("PLC_RECEIVER_VALUE")]
        public class PlcReceiverValue
        {
            [Dapper.Contrib.Extensions.ExplicitKey]
            public DateTime dttm { get; set; }
            [Dapper.Contrib.Extensions.Computed]
            public DateTime dttm_upload { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public Int16 tag_num { get; set; }
            public double tag_value { get; set; }

            public PlcReceiverValue(Receiver receiver)
            {
                dttm = receiver.dttm;
                dttm_upload = receiver.dttm_upload;
                tag_num = receiver.tag_num;
            }

            public PlcReceiverValue()
            {

            }
        }

        [Dapper.Contrib.Extensions.Table("PLC_RECEIVER_BIT")]
        public class PlcReceiverBit
        {
            [Dapper.Contrib.Extensions.ExplicitKey]
            public DateTime dttm { get; set; }
            [Dapper.Contrib.Extensions.Computed]
            public DateTime dttm_upload { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public Int16 tag_num { get; set; }
            public bool tag_value { get; set; }

            public PlcReceiverBit(Receiver receiver)
            {
                dttm = receiver.dttm;
                dttm_upload = receiver.dttm_upload;
                tag_num = receiver.tag_num;
            }

            public PlcReceiverBit()
            {

            }
        }
    }
}
