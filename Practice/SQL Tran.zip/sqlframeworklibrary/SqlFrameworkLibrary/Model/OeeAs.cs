﻿using Dapper;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.Model
{
    public class OeeAs
    {
        public class OeeAsCarModl
        {
            public int sn { get; set; }
            public string year { get; set; }
            public string big_or_small { get; set; }
            public string modl { get; set; }
            public double dst { get; set; }
            public double equivalent_units { get; set; }
            public DateTime build_time { get; set; }
            public bool is_invalid { get; set; }
            [Dapper.Contrib.Extensions.Computed]
            public DateTime? invalid_time { get; set; }
        }

        //public class AlcCalendar
        //{
        //    public DateTime begn_dttm { get; set; }
        //    public DateTime end_dttm { get; set; }
        //}

        public class OeeAsCcrPrdt
        {
            public string modl_chs_no { get; set; }
            public int? car_qty { get; set; }

            //public int car_qty_output
            //{
            //    get
            //    {
            //        if (car_qty is null)
            //            car_qty = int.MaxValue;
            //        return (int)car_qty;
            //    }
            //}

            public string modl { get; set; }
            public DateTime ccr_prdt_dttm { get; set; }
        }

        // ========================================================================
        [Dapper.Contrib.Extensions.Table("YULON_AS_CAR_PRODUCTIVITY")]
        public class OeeAsCarProductivity
        {
            [Dapper.Contrib.Extensions.Key]
            public int sn { get; set; }
            public string year { get; set; }
            public string factory { get; set; }
            public string zone { get; set; }
            public double jan { get; set; }
            public double feb { get; set; }
            public double mar { get; set; }
            public double apr { get; set; }
            public double may { get; set; }
            public double jun { get; set; }
            public double jul { get; set; }
            public double aug { get; set; }
            public double sep { get; set; }
            public double oct { get; set; }
            public double nov { get; set; }
            public double dec { get; set; }
            public double jan_base { get; set; }
            public double feb_base { get; set; }
            public double mar_base { get; set; }
            public double apr_base { get; set; }
            public double may_base { get; set; }
            public double jun_base { get; set; }
            public double jul_base { get; set; }
            public double aug_base { get; set; }
            public double sep_base { get; set; }
            public double oct_base { get; set; }
            public double nov_base { get; set; }
            public double dec_base { get; set; }
            public double mix_big_equvalent_units { get; set; }
            public double mix_small_equvalent_units { get; set; }
            public DateTime build_time { get; set; }
            public bool is_invalid { get; set; }
            public DateTime? invalid_time { get; set; }
        }

        // ========================================================================
        [Dapper.Contrib.Extensions.Table("YULON_AS_DAY_RECORD")]
        public class OeeAsDayRecord
        {
            [Dapper.Contrib.Extensions.Computed]
            [Dapper.IgnoreUpdate]
            public int sn { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            //[Dapper.Required]
            public string factory { get; set; } = "";
            [Dapper.Contrib.Extensions.ExplicitKey]
            //[Dapper.Required]
            public string zone { get; set; } = "";
            [Dapper.Contrib.Extensions.ExplicitKey]
            //[Dapper.Required]
            public string line { get; set; } = "";
            [Dapper.Contrib.Extensions.ExplicitKey]
            //[Dapper.Required]
            public DateTime RQ { get; set; } = DateTime.Now;
            [Dapper.Contrib.Extensions.ExplicitKey]
            //[Dapper.Required]
            public int section { get; set; } = -1;
            public bool is_work_day { get; set; }
            public double takt_time { get; set; }
            public double jph_targ { get; set; }
            public double jph_real { get; set; }
            public double pcs_day_plan { get; set; }
            public double pcs_day_predict { get; set; }
            public double pcs_day_target { get; set; }
            public double pcs_day_real { get; set; }
            //public double pcs_day_real_out { get; set; }
            public string pcs_day_detail { get; set; }
            public string open_time_predict { get; set; }
            public string open_time_real { get; set; }
            public string close_time_predict { get; set; }
            public string close_time_real { get; set; }
            public string open_time_predict_1st { get; set; }
            public string open_time_predict_2nd { get; set; }
            public string open_time_predict_3rd { get; set; }
            public string open_time_real_1st { get; set; }
            public string open_time_real_2nd { get; set; }
            public string open_time_real_3rd { get; set; }
            public string close_time_predict_1st { get; set; }
            public string close_time_predict_2nd { get; set; }
            public string close_time_predict_3rd { get; set; }
            public string close_time_real_1st { get; set; }
            public string close_time_real_2nd { get; set; }
            public string close_time_real_3rd { get; set; }
            public double kwh_day_predict { get; set; }
            public double kwh_day_real { get; set; }
            public double kwh_mon_predict { get; set; }
            public double kwh_mon_real { get; set; }
            public double pcs_mon_predict { get; set; }
            public double pcs_mon_targ { get; set; }
            public double pcs_mon_real { get; set; }
            public double runtime_targ { get; set; }
            public double runtime_real { get; set; }
            public double warmtime_targ { get; set; }
            public double warmtime_real { get; set; }
            public double subruntime_targ { get; set; }
            public double subruntime_real { get; set; }
            public double oee_runtime_targ { get; set; }
            public double oee_runtime_real { get; set; }
            public double oee_a_sum { get; set; }
            public double oee_a1 { get; set; }
            public double oee_a2 { get; set; }
            public double oee_a3 { get; set; }
            public double oee_a4 { get; set; }
            public double oee_a5 { get; set; }
            public double oee_a6 { get; set; }
            public double oee_a7 { get; set; }
            public double oee_a8 { get; set; }
            public double oee_a9 { get; set; }
            public double oee_else_a1 { get; set; }
            public double oee_else_a2 { get; set; }
            public double oee_else_a3 { get; set; }
            public double oee_p_sum { get; set; }
            public double oee_p1 { get; set; }
            public double oee_p2 { get; set; }
            public double oee_p3 { get; set; }
            public double oee_p4 { get; set; }
            public double oee_p5 { get; set; }
            public double oee_p6 { get; set; }
            public double oee_p7 { get; set; }
            public double oee_p8 { get; set; }
            public double oee_p9 { get; set; }
            public double oee_else_p1 { get; set; }
            public double oee_else_p2 { get; set; }
            public double oee_else_p3 { get; set; }
            public double oee_pcs_day { get; set; }

            // 當初沒有取好名字 容易搞混 在修改資料庫前 先維持這種方式
            [Dapper.Contrib.Extensions.Computed]
            public double oee_check_day { get { return oee_pcs_day; } set { oee_pcs_day = value; } }
            public double oee_defect_day { get; set; }
            public double oee_pcs_day_member1 { get; set; }
            public double oee_pcs_day_member2 { get; set; }
            public double oee_pcs_day_member3 { get; set; }
            public double oee_q_sum { get; set; }
            public double oee_q1 { get; set; }
            public double oee_q2 { get; set; }
            public double oee_q3 { get; set; }
            public double oee_q4 { get; set; }
            public double oee_q5 { get; set; }
            public double oee_q6 { get; set; }
            public double oee_q7 { get; set; }
            public double oee_q8 { get; set; }
            public double oee_q9 { get; set; }
            public double oee_q1_member1 { get; set; }
            public double oee_q1_member2 { get; set; }
            public double oee_q1_member3 { get; set; }
            public double oee_q2_member1 { get; set; }
            public double oee_q2_member2 { get; set; }
            public double oee_q2_member3 { get; set; }
            public double oee_q3_member1 { get; set; }
            public double oee_q3_member2 { get; set; }
            public double oee_q3_member3 { get; set; }
            public double times_log1 { get; set; }
            public double times_log2 { get; set; }
            public double times_log3 { get; set; }
            public double times_log4 { get; set; }
            public double times_log5 { get; set; }
            public double times_log6 { get; set; }
            public double times_log7 { get; set; }
            public double times_log8 { get; set; }
            public double times_log9 { get; set; }

            public double value_log1 { get; set; }
            public double value_log2 { get; set; }
            public double value_log3 { get; set; }
            public double value_log4 { get; set; }
            public double value_log5 { get; set; }
            public double value_log6 { get; set; }
            public double value_log7 { get; set; }
            public double value_log8 { get; set; }
            public double value_log9 { get; set; }

            [Dapper.Contrib.Extensions.Computed]
            public double oee_a_targ { get; set; }
            [Dapper.Contrib.Extensions.Computed]
            public double oee_p_targ { get; set; }
            [Dapper.Contrib.Extensions.Computed]
            public double oee_q_targ { get; set; }
        }
        // ========================================================================
        [Dapper.Contrib.Extensions.Table("YULON_AS_DEV_KWH_PARA")]
        public class OeeAsDevKwhPara
        {
            [Dapper.Contrib.Extensions.Key]
            public string factory { get; set; }
            [Dapper.Contrib.Extensions.Key]
            public string zone { get; set; }
            [Dapper.Contrib.Extensions.Key]
            public string cabinet { get; set; }
            public string main_sys_name { get; set; }
            public string main_sys { get; set; }
            public string sub_sys_name { get; set; }
            [Dapper.Contrib.Extensions.Key]
            public string sub_sys { get; set; }
            public string tree_1st { get; set; }
            public string tree_2st { get; set; }
            public string tree_3st { get; set; }
            public string dev_num { get; set; }
            public string dev_name { get; set; }
            public string dev_id { get; set; }
            public string open_mode { get; set; }
            public string off_mode { get; set; }
            public double? run_time_kwh { get; set; }
            public double? rest_time_kwh { get; set; }
            public double? off_time_kwh { get; set; }
            public string rest_time_arr { get; set; }
            public double? stable_time_min { get; set; }
            public double? firing_kwh { get; set; }
            public bool? is_float_by_time { get; set; }
            public string comment { get; set; }
            public string step_check_man { get; set; }
            public string step_duty_man { get; set; }
            public DateTime? step_finish_time { get; set; }
            public DateTime? build_time { get; set; }
            public bool? is_invalid { get; set; }
            public DateTime? invalid_time { get; set; }

        }

        [Dapper.Contrib.Extensions.Table("YULON_AS_ERROR_HISTORY")]
        public class OeeAsErrorHistory
        {
            [Dapper.Contrib.Extensions.Computed]
            public int sn { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public string factory { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public string zone { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public string line { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public DateTime RQ { get; set; }
            public string SJ { get; set; }
            //[Dapper.Contrib.Extensions.Computed]
            //public DateTime time_star { get; set; }
            //[Dapper.Contrib.Extensions.Computed]
            //public DateTime time_stop { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public string sys_autotype { get; set; }
            public string sys_autotype1 { get; set; }
            public string sys_autotype2 { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public string sys_detail { get; set; }
            public string sys_detail1 { get; set; }
            public string sys_detail2 { get; set; }
            public string sys_detail3 { get; set; }

            public string msg_device { get; set; }
            public string msg_device_part { get; set; }
            public string msg_car_type { get; set; }
            public string msg_car_color { get; set; }
            public string msg_car_part { get; set; }
            public string msg_car_no { get; set; }
            public string msg_eng_type { get; set; }
            public string msg_eng_no { get; set; }


            public string sys_target { get; set; }
            public string sys_real { get; set; }
            public double? sys_minute { get; set; }
            public double? sys_pcs { get; set; }
            public double? sys_kwh { get; set; }
            public string msg_reason { get; set; }
            public string msg_response { get; set; }
            [Dapper.Contrib.Extensions.Computed]
            public string msg_reason_get 
            {
                get
                {
                    string str = "待人員判定";
                    if (string.IsNullOrEmpty(msg_reason))
                        return str;
                    else
                        return msg_reason;
                }
            }
            [Dapper.Contrib.Extensions.Computed]
            public string msg_response_get
            {
                get
                {
                    string str = "待人員判定";
                    if (string.IsNullOrEmpty(msg_response))
                        return str;
                    else
                        return msg_response;
                }
            }
            
            [Dapper.Contrib.Extensions.Computed]
            public string file_number { get; set; }
            public string msg_inspection { get; set; }
            public string msg_process { get; set; }
            public string msg_confirm { get; set; }
            public bool? msg_isdispatch { get; set; }
            public bool? msg_isrepair { get; set; }
            public bool? msg_isconfirm { get; set; }
            public string dispatch_name_man { get; set; }
            public string dispatch_name_boss { get; set; }
            public string response_name_man { get; set; }
            public string response_name_boss { get; set; }
            public DateTime? time_dispatch { get; set; }
            public DateTime? time_repair { get; set; }
            public DateTime? time_confirm { get; set; }
            public string msg_appendix { get; set; }
            public int? sys_happen_again { get; set; }
            public DateTime? build_time { get; set; }
            public bool? is_visible { get; set; }
            public bool? is_calc_oee { get; set; }
        }

        [Dapper.Contrib.Extensions.Table("YULON_AS_ERROR_HISTORY")]
        public class UpOeeAsErrorHistory
        {
            [Dapper.Contrib.Extensions.ExplicitKey]
            public string factory { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public string zone { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public string line { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public DateTime RQ { get; set; }
            public string SJ { get; set; }

            [Dapper.Contrib.Extensions.ExplicitKey]
            public string sys_autotype { get; set; }

            [Dapper.Contrib.Extensions.ExplicitKey]
            public string sys_detail { get; set; }
            public string msg_inspection { get; set; }
            public string sys_real { get; set; }
            public double? sys_minute { get; set; }
            public double? sys_pcs { get; set; }
        }

        [Dapper.Contrib.Extensions.Table("YULON_AS_ERROR_HISTORY")]
        public class UpMsg_car_part
        {
            [Dapper.Contrib.Extensions.ExplicitKey]
            public string factory { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public string zone { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public string line { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public DateTime RQ { get; set; }

            [Dapper.Contrib.Extensions.ExplicitKey]
            public string sys_autotype { get; set; }

            [Dapper.Contrib.Extensions.ExplicitKey]
            public string sys_detail { get; set; }
            public string msg_car_part { get; set; }
            public string sys_real { get; set; }
            public string msg_inspection { get; set; }
        }

        public class OEE_SHOW_TITLE
        {
            public string oee_a1 { get; set; }
            public string oee_a2 { get; set; }
            public string oee_a3 { get; set; }
            public string oee_a4 { get; set; }
            public string oee_a5 { get; set; }
            public string oee_a6 { get; set; }
            public string oee_a7 { get; set; }
            public string oee_a8 { get; set; }
            public string oee_a9 { get; set; }
            public string oee_p1 { get; set; }
            public string oee_p2 { get; set; }
            public string oee_p3 { get; set; }
            public string oee_p4 { get; set; }
            public string oee_p5 { get; set; }
            public string oee_p6 { get; set; }
            public string oee_p7 { get; set; }
            public string oee_p8 { get; set; }
            public string oee_p9 { get; set; }
            public string oee_q1 { get; set; }
            public string oee_q2 { get; set; }
            public string oee_q3 { get; set; }
            public string oee_q4 { get; set; }
            public string oee_q5 { get; set; }
            public string oee_q6 { get; set; }
            public string oee_q7 { get; set; }
            public string oee_q8 { get; set; }
            public string oee_q9 { get; set; }
        }

    }
}
