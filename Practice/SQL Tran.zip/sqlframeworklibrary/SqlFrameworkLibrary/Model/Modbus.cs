﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.Model
{
    public class Modbus
    {
        [Dapper.Contrib.Extensions.Table("MODBUS_RECEIVER_VALUE")]
        public class ModbusReceiverValue
        {
            [Dapper.Contrib.Extensions.ExplicitKey]
            public DateTime dttm { get; set; }
            [Dapper.Contrib.Extensions.Computed]
            public DateTime dttm_upload { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public Int16 tag_num { get; set; }
            public double tag_value { get; set; }

            public ModbusReceiverValue(Receiver receiver)
            {
                dttm = receiver.dttm;
                dttm_upload = receiver.dttm_upload;
                tag_num = receiver.tag_num;
            }
        }

        [Dapper.Contrib.Extensions.Table("MODBUS_RECEIVER_BIT")]
        public class ModbusReceiverBit
        {
            [Dapper.Contrib.Extensions.ExplicitKey]
            public DateTime dttm { get; set; }
            [Dapper.Contrib.Extensions.Computed]
            public DateTime dttm_upload { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public Int16 tag_num { get; set; }
            public bool tag_value { get; set; }

            public ModbusReceiverBit(Receiver receiver)
            {
                dttm = receiver.dttm;
                dttm_upload = receiver.dttm_upload;
                tag_num = receiver.tag_num;
            }
        }

        [Dapper.Contrib.Extensions.Table("MODBUS_RECEIVER_ASCII")]
        public class ModbusReceiverAscii
        {
            [Dapper.Contrib.Extensions.ExplicitKey]
            public DateTime dttm { get; set; }
            [Dapper.Contrib.Extensions.Computed]
            public DateTime dttm_upload { get; set; }
            [Dapper.Contrib.Extensions.ExplicitKey]
            public Int16 tag_num { get; set; }
            public string tag_value { get; set; }

            public ModbusReceiverAscii(Receiver receiver)
            {
                dttm = receiver.dttm;
                dttm_upload = receiver.dttm_upload;
                tag_num = receiver.tag_num;
            }
        }

        
    }
}
