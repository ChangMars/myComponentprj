﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.Model
{
    public class Receiver
    {
        public DateTime dttm { get; set; }
        public DateTime dttm_upload { get; set; }
        public Int16 tag_num { get; set; }
    }
}
