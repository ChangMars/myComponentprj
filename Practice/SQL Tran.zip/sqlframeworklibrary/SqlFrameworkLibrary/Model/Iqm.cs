﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.Model
{
    public class Iqm
    {
        public class IqmRowData
        {
            public string MODEL { get; set; }
            public string CARNO { get; set; }
            public string TI_LINE { get; set; }
            public string OPERATION { get; set; }
            public string OPERATION_NAME { get; set; }
            public DateTime? START_TIME { get; set; }
            public DateTime? END_TIME { get; set; }
        }

        public class IqmOperationModel
        {
            public string operation { get; }
            public string operation_name { get; }
            public int sort { get; }
            public bool inline { get; }
            public int group_index { get; }
            public string group_name { get; }
        }
    }
}
