﻿using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.Model
{
    public class Bind
    {
        [Dapper.Contrib.Extensions.Table("YULON_BIND_SPC_ENG_EPM_RECORD")]
        public class BindSpcEngEpmRecord
        {
            //[Dapper.Contrib.Extensions.ExplicitKey]
            //public int sn { get; set; }
            public string emdl { get; set; }
            public string engn_no { get; set; }
            public string car_serial { get; set; }

            //[Dapper.Contrib.Extensions.ExplicitKey]
            public DateTime eo_dttm { get; set; }

            public DateTime? create_dttm { get; set; }
            public DateTime? update_dttm { get; set; }

            public string Equipment_No { get; set; }
            public string Equipment_Name { get; set; }
            public string Create_Time { get; set; }
            public string Detail_Item_No { get; set; }
            public string Detail_Item_Actual { get; set; }

            public override bool Equals(object obj)
            {
                if (obj is BindSpcEngEpmRecord)
                {
                    BindSpcEngEpmRecord v = obj as BindSpcEngEpmRecord;
                    return eo_dttm == v.eo_dttm && Create_Time == v.Create_Time && Detail_Item_No == v.Detail_Item_No;
                }
                return false;
            }
            public override int GetHashCode()
            {
                return eo_dttm.GetHashCode() ^ Create_Time.GetHashCode() ^ Detail_Item_No.GetHashCode();
            }
        }

        [Dapper.Contrib.Extensions.Table("YULON_BIND_SPC_ALC_ENGN")]
        public class BindSpcAlcEngn
        {
            //[Dapper.IgnoreInsert]
            //[Dapper.IgnoreUpdate]
            //public int sn { get; set; }
            public string emdl { get; set; }
            public string engn_no { get; set; }
            public string car_serial { get; set; }

            [Dapper.Contrib.Extensions.ExplicitKey]
            public DateTime eo_dttm { get; set; }

            public DateTime? create_dttm { get; set; }
            public DateTime? update_dttm { get; set; }

            public override bool Equals(object obj)
            {
                if (obj is BindSpcAlcEngn)
                {
                    BindSpcAlcEngn v = obj as BindSpcAlcEngn;
                    return eo_dttm == v.eo_dttm;
                }
                return false;
            }
            public override int GetHashCode()
            {
                return eo_dttm.GetHashCode();
            }
        }

        [Dapper.Contrib.Extensions.Table("YULON_BIND_ALC_SPC_PARA")]
        public class BindAlcEmdlSpcPara
        {
            [Dapper.Key]
            public string equip_no { get; set; }
            [Dapper.Key]
            public string emdl { get; set; }
            [Dapper.Key]
            public string car_serial { get; set; }
            public int upload_count { get; set; }
            [Dapper.Key]
            public DateTime update_dttm { get; set; }
            public string update_user { get; set; }

            public override bool Equals(object obj)
            {
                if (obj is BindAlcEmdlSpcPara)
                {
                    BindAlcEmdlSpcPara v = obj as BindAlcEmdlSpcPara;
                    return equip_no == v.equip_no && emdl == v.emdl && car_serial == v.car_serial && upload_count == v.upload_count;
                }
                return false;
            }
            public override int GetHashCode()
            {
                return equip_no.GetHashCode() ^ emdl.GetHashCode() ^ car_serial.GetHashCode() ^ upload_count.GetHashCode();
            }
        }

        [Dapper.Contrib.Extensions.Table("YULON_BIND_CI_SI_DATA")]
        public class BindCiSiData : BindCiSiBasicData
        {
            public string Section { get; set; }
        }

        public class BindCiSiBasicData
        {
            [Dapper.Key]
            public DateTime DateTime { get; set; }
            [Dapper.Key]
            public Int32 DeviceID { get; set; }
            [Dapper.Key]
            public Int32 SkidNo { get; set; }

            public string CarNo { get; set; }

            public string CarType { get; set; }
            public string CarColor { get; set; }
            public string CarType2 { get; set; }
            public string CarColor2 { get; set; }
            public Int32 Counter { get; set; }
            public Int32 Height { get; set; }
            public Int32 Rotation { get; set; }
            public Int32 FlowRate { get; set; }
            public Int32 FlowRateSV { get; set; }
            public Int32 TurbineSpeed { get; set; }
            public Int32 TurbineSpeedSV { get; set; }
            public Int32 HighVoltage { get; set; }
            public Int32 HighVoltageSV { get; set; }
            public Int32 ShapingAir { get; set; }
            public Int32 ShapingAirSV { get; set; }

            public override bool Equals(object obj)
            {
                if (obj is BindCiSiBasicData)
                {
                    BindCiSiBasicData v = obj as BindCiSiBasicData;
                    return DateTime.ToString("yyyy/MM/dd HH:mm:ss") == v.DateTime.ToString("yyyy/MM/dd HH:mm:ss") && DeviceID.ToString() == v.DeviceID.ToString() && SkidNo.ToString() == v.SkidNo.ToString();
                }
                return false;
            }
            public override int GetHashCode()
            {
                return DateTime.ToString("yyyy/MM/dd HH:mm:ss").GetHashCode() ^ DeviceID.ToString().GetHashCode() ^ SkidNo.ToString().GetHashCode();
            }

            //public void SetTableName()
            //{
            //    SqlMapperExtensions.TableNameMapper = (type) =>
            //    {
            //        // do something here to pluralize the name of the type
            //        return type.Name;
            //    };
            //}
        }

        [Dapper.Contrib.Extensions.Table("YULON_BIND_CI_SI_CAR")]
        public class BindCiSiCar
        {
            [Dapper.Key]
            public int SkidID { get; set; }
            public string CkptID { get; set; }
            public DateTime DateTime { get; set; }

            public int SkidNo { get; set; }

            public string CarNo { get; set; }
            public int TypeCode { get; set; }
            public int ColorCode { get; set; }
            public string CarType { get; set; }
            public string CarColor { get; set; }
            public string CarType2 { get; set; }
            public string CarColor2 { get; set; }

            public override bool Equals(object obj)
            {
                if (obj is BindCiSiCar)
                {
                    BindCiSiCar v = obj as BindCiSiCar;
                    return SkidID == v.SkidID;
                }
                return false;
            }
            public override int GetHashCode()
            {
                return SkidID.GetHashCode();
            }

            //public void SetTableName()
            //{
            //    SqlMapperExtensions.TableNameMapper = (type) =>
            //    {
            //        // do something here to pluralize the name of the type
            //        return type.Name;
            //    };
            //}
        }
    }
}
