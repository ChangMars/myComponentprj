﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.Model
{
    public class AskCb
	{
        public class YULON_AS_DEV_KWH_VALUE
        {
            public string sn { get; set; }         
            public string factory { get; set; }
            public string zone { get; set; }
            public bool is_real { get; set; }
            public double all_value { get; set; }
            public double a1_value { get; set; }
            public double a2_value { get; set; }
            public double a3_value { get; set; }
            public double a4_value { get; set; }
            public double a5_value { get; set; }
            public double a6_value { get; set; }
            public double a7_value { get; set; }
            public double a8_value { get; set; }
            public double a9_value { get; set; }
            public double a10_value { get; set; }
            public DateTime dttm { get; set; }
        }
    }
}
