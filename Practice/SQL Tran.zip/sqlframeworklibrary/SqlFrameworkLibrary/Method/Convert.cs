﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlFrameworkLibrary.Method
{
    public class Convert
    {
        static public System.Data.DataTable Convert2DataTable(List<dynamic> v, string name = "")
        {
            var json = JsonConvert.SerializeObject(v);
            System.Data.DataTable dataTable = (System.Data.DataTable)JsonConvert.DeserializeObject(json, (typeof(System.Data.DataTable)));

            if (!string.IsNullOrEmpty(name))
                dataTable.TableName = name;

            return dataTable;
        }

        static public T Convert2Type<T>(List<dynamic> v) where T : class
        {
            var json = JsonConvert.SerializeObject(v);
            T dataTable = (T)JsonConvert.DeserializeObject(json, (typeof(T)));
            return dataTable;
        }

        /// <summary>
        /// 會出錯
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="v"></param>
        /// <returns></returns>
        static public List<T> Convert2Type2<T>(List<dynamic> v) where T : class
        {
            var json = JsonConvert.SerializeObject(v);
            List<T> dataTable = (List<T>)JsonConvert.DeserializeObject(json, (typeof(T)));
            return dataTable;
        }

        static public List<dynamic> Convert2Type<T>(List<T> v) where T : class
        {
            var json = JsonConvert.SerializeObject(v);
            List<dynamic> dataTable = (List<dynamic>)JsonConvert.DeserializeObject(json, typeof(List<dynamic>));
            return dataTable;
        }

        public static string TableNameMapper(Type type)
        {
            dynamic tableattr = type.GetCustomAttributes(false).SingleOrDefault(attr => attr.GetType().Name == "TableAttribute");
            var name = string.Empty;

            if (tableattr != null)
            {
                name = tableattr.Name;
            }

            return name;
        }
    }
}
